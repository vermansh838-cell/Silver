"""
E.V. V3.1 — Living Mood Engine (E.V. state, not claimed user emotion).
"""
from __future__ import annotations
import json
import os
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from threading import Lock
import sys

def _base() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

PATH = _base() / "memory" / "mood_state.json"
_lock = Lock()

MOODS = ("ENERGIZED", "FOCUSED", "THOUGHTFUL", "CALM", "PLAYFUL", "CONCERNED", "SERIOUS")

@dataclass
class MoodState:
    name: str = "CALM"
    intensity: float = 0.5
    source: str = "default"
    confidence: float = 0.5
    timestamp: str = ""
    manual: bool = False

def _empty():
    return {
        "mood": asdict(MoodState(timestamp=datetime.now().isoformat(timespec="seconds"))),
        "mode_manual": False,  # AUTO vs MANUAL mood
        "manual_mood": "CALM",
        "history": [],
    }

def load() -> dict:
    with _lock:
        if not PATH.exists():
            data = _empty()
            _save(data)
            return data
        try:
            data = json.loads(PATH.read_text(encoding="utf-8"))
            base = _empty()
            for k, v in base.items():
                data.setdefault(k, v)
            return data
        except Exception:
            return _empty()

def _save(data: dict):
    PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, PATH)

def save(data: dict):
    with _lock:
        _save(data)

def get_mood() -> MoodState:
    data = load()
    m = data.get("mood") or {}
    try:
        return MoodState(**{k: m.get(k, v) for k, v in asdict(MoodState()).items()})
    except Exception:
        return MoodState()

def set_manual(mood: str | None):
    data = load()
    if mood is None:
        data["mode_manual"] = False
    else:
        mood = mood.upper()
        if mood not in MOODS:
            mood = "CALM"
        data["mode_manual"] = True
        data["manual_mood"] = mood
        old = (data.get("mood") or {}).get("name")
        data["mood"] = asdict(MoodState(
            name=mood, intensity=0.8, source="manual", confidence=1.0,
            timestamp=datetime.now().isoformat(timespec="seconds"), manual=True,
        ))
        if old and old != mood:
            data.setdefault("history", []).insert(0, {
                "from": old, "to": mood, "reason": "Manual", "ts": time.time()
            })
            data["history"] = data["history"][:20]
    save(data)

def infer_mood(screen_category: str = "", mode: str = "CHAT", problem: str = "", focus_min: float = 0) -> MoodState:
    data = load()
    if data.get("mode_manual"):
        m = data.get("manual_mood") or "CALM"
        return MoodState(name=m, intensity=0.8, source="manual", confidence=1.0,
                         timestamp=datetime.now().isoformat(timespec="seconds"), manual=True)

    name, source, conf, intensity = "CALM", "default", 0.5, 0.5
    cat = (screen_category or "").upper()
    mode = (mode or "CHAT").upper()

    if problem:
        name, source, conf, intensity = "SERIOUS", "problem", 0.75, 0.7
    elif mode == "NIGHT":
        name, source, conf, intensity = "CALM", "night_mode", 0.8, 0.4
    elif mode == "WORK" or cat == "CODING":
        name, source, conf, intensity = "FOCUSED", "coding", 0.85, 0.8
        if focus_min >= 60:
            intensity = 0.9
    elif mode == "CREATIVE" or cat in ("DESIGN", "CREATIVE"):
        name, source, conf, intensity = "PLAYFUL", "creative", 0.7, 0.65
    elif mode == "AGENT":
        name, source, conf, intensity = "SERIOUS", "agent", 0.75, 0.7
    elif mode == "MEETING":
        name, source, conf, intensity = "THOUGHTFUL", "meeting", 0.7, 0.6
    elif cat == "GAMING":
        name, source, conf, intensity = "PLAYFUL", "gaming", 0.6, 0.55
    elif mode == "HEALTH":
        name, source, conf, intensity = "CALM", "health", 0.65, 0.5

    # RAM concern
    try:
        # optional external
        pass
    except Exception:
        pass

    st = MoodState(
        name=name, intensity=intensity, source=source, confidence=conf,
        timestamp=datetime.now().isoformat(timespec="seconds"), manual=False,
    )
    old = (data.get("mood") or {}).get("name")
    data["mood"] = asdict(st)
    if old and old != name:
        data.setdefault("history", []).insert(0, {
            "from": old, "to": name,
            "reason": {"coding": "Focused work", "problem": "Issue detected", "night_mode": "Night mode",
                       "creative": "Creative context", "agent": "Agent mode", "meeting": "Meeting",
                       "default": "Context shift"}.get(source, "Context shift"),
            "ts": time.time(),
        })
        data["history"] = data["history"][:20]
    save(data)
    return st

def ui_params(mood: MoodState, mode: str = "CHAT") -> dict:
    """Centralized UIThemeState-like parameters for core animation / intensity."""
    name = (mood.name or "CALM").upper()
    mode = (mode or "CHAT").upper()
    speed = 0.04
    glow = 0.5
    noise = 0.5  # visual noise allowance
    if name == "FOCUSED":
        speed, glow, noise = 0.03, 0.35, 0.25
    elif name == "CALM":
        speed, glow, noise = 0.025, 0.3, 0.2
    elif name == "ENERGIZED":
        speed, glow, noise = 0.08, 0.7, 0.6
    elif name == "THOUGHTFUL":
        speed, glow, noise = 0.035, 0.4, 0.3
    elif name == "PLAYFUL":
        speed, glow, noise = 0.06, 0.55, 0.55
    elif name == "CONCERNED":
        speed, glow, noise = 0.05, 0.45, 0.35
    elif name == "SERIOUS":
        speed, glow, noise = 0.03, 0.4, 0.2
    if mode == "NIGHT":
        glow *= 0.5
        speed *= 0.7
        noise *= 0.5
    if mode == "WORK" and name == "FOCUSED":
        noise = min(noise, 0.2)
    return {
        "mood": name,
        "core_speed": speed,
        "glow": glow,
        "noise": noise,
        "intensity": mood.intensity,
        "status_line": {
            "FOCUSED": "Working with you.",
            "CALM": "Steady and quiet.",
            "ENERGIZED": "Ready when you are.",
            "THOUGHTFUL": "Thinking it through.",
            "PLAYFUL": "Keeping it light.",
            "CONCERNED": "Watching carefully.",
            "SERIOUS": "Staying precise.",
        }.get(name, ""),
    }
