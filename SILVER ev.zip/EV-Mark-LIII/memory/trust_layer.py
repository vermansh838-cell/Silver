"""
E.V. Trust Layer + reversible action history.

SAFE      — read, search, open, inspect
CONFIRM   — edit, send, schedule
ALWAYS    — delete, shutdown, financial, irreversible

Tracks reversible actions for: "Undo what you just did."
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from threading import Lock
from typing import Any, Callable, Optional


class TrustLevel(str, Enum):
    SAFE = "SAFE"
    CONFIRM = "CONFIRM"
    ALWAYS_CONFIRM = "ALWAYS_CONFIRM"


# Tool / action → trust level
TRUST_MAP: dict[str, TrustLevel] = {
    # SAFE
    "web_search": TrustLevel.SAFE,
    "open_app": TrustLevel.SAFE,
    "weather": TrustLevel.SAFE,
    "screen_process": TrustLevel.SAFE,
    "file_read": TrustLevel.SAFE,
    "code_helper": TrustLevel.SAFE,
    "daily_briefing": TrustLevel.SAFE,
    "calendar_list": TrustLevel.SAFE,
    # CONFIRM
    "send_message": TrustLevel.CONFIRM,
    "file_write": TrustLevel.CONFIRM,
    "file_edit": TrustLevel.CONFIRM,
    "calendar_create": TrustLevel.CONFIRM,
    "calendar_update": TrustLevel.CONFIRM,
    "draft_email": TrustLevel.CONFIRM,
    "browser_control": TrustLevel.CONFIRM,
    "computer_control": TrustLevel.CONFIRM,
    # ALWAYS
    "file_delete": TrustLevel.ALWAYS_CONFIRM,
    "shutdown": TrustLevel.ALWAYS_CONFIRM,
    "shutdown_jarvis": TrustLevel.ALWAYS_CONFIRM,
    "delete": TrustLevel.ALWAYS_CONFIRM,
}


def classify(action_name: str) -> TrustLevel:
    name = (action_name or "").lower().strip()
    if name in TRUST_MAP:
        return TRUST_MAP[name]
    # Heuristics
    if any(k in name for k in ("delete", "remove", "shutdown", "kill", "format")):
        return TrustLevel.ALWAYS_CONFIRM
    if any(k in name for k in ("send", "write", "edit", "modify", "schedule", "create", "post")):
        return TrustLevel.CONFIRM
    return TrustLevel.SAFE


@dataclass
class ReversibleAction:
    id: str
    name: str
    description: str
    undo_fn: Optional[Callable[[], Any]] = None  # not serialized
    undo_hint: str = ""
    created_at: float = field(default_factory=time.time)
    undone: bool = False
    meta: dict = field(default_factory=dict)


class TrustLayer:
    def __init__(self, max_history: int = 50):
        self._lock = Lock()
        self._history: list[ReversibleAction] = []
        self._max = max_history

    def needs_approval(self, action_name: str) -> TrustLevel:
        return classify(action_name)

    def record(
        self,
        name: str,
        description: str,
        *,
        undo_fn: Callable[[], Any] | None = None,
        undo_hint: str = "",
        meta: dict | None = None,
    ) -> ReversibleAction:
        act = ReversibleAction(
            id=str(uuid.uuid4())[:8],
            name=name,
            description=description,
            undo_fn=undo_fn,
            undo_hint=undo_hint or f"Reverse: {description}",
            meta=meta or {},
        )
        with self._lock:
            self._history.append(act)
            if len(self._history) > self._max:
                self._history = self._history[-self._max:]
        return act

    def last_reversible(self) -> Optional[ReversibleAction]:
        with self._lock:
            for act in reversed(self._history):
                if not act.undone and act.undo_fn is not None:
                    return act
        return None

    def undo_last(self) -> tuple[bool, str]:
        """
        Attempt to undo the most recent reversible action.
        Returns (ok, message).
        """
        act = self.last_reversible()
        if act is None:
            return False, "Nothing reversible to undo."
        try:
            act.undo_fn()  # type: ignore
            act.undone = True
            return True, f"Undid: {act.description}"
        except Exception as e:
            return False, f"Could not undo: {e}"

    def recent(self, n: int = 10) -> list[dict]:
        with self._lock:
            out = []
            for a in self._history[-n:]:
                out.append({
                    "id": a.id,
                    "name": a.name,
                    "description": a.description,
                    "undo_hint": a.undo_hint,
                    "undone": a.undone,
                    "created_at": a.created_at,
                    "reversible": a.undo_fn is not None,
                })
            return out


trust = TrustLayer()
