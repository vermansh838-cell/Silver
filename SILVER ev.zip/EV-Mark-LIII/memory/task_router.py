"""
E.V. Intelligent Task Routing

FAST | CONVERSATION | SYSTEM | SEARCH | VISION | RESEARCH | CODE | AGENT | DEEP_RESEARCH

Simple commands must stay extremely fast — no heavyweight agent path.
"""
from __future__ import annotations

import re
from enum import Enum
from typing import Optional


class TaskClass(str, Enum):
    FAST = "FAST"
    CONVERSATION = "CONVERSATION"
    SYSTEM = "SYSTEM"
    SEARCH = "SEARCH"
    VISION = "VISION"
    RESEARCH = "RESEARCH"
    CODE = "CODE"
    AGENT = "AGENT"
    DEEP_RESEARCH = "DEEP_RESEARCH"


# Order matters — first match wins for keyword sets
_RULES: list[tuple[TaskClass, list[str]]] = [
    (TaskClass.FAST, [
        r"\bwhat time\b", r"\bwhat'?s the time\b", r"\bdate\b",
        r"\b\d+\s*%\s*of\b", r"\bcalculate\b", r"\bconvert\b",
        r"\bvolume\b", r"\bmute\b", r"\bunmute\b",
    ]),
    (TaskClass.SYSTEM, [
        r"\bopen\b", r"\blaunch\b", r"\bstart\b", r"\bclose\b",
        r"\bquit\b", r"\bshutdown\b", r"\brestart\b",
        r"\bplay\b", r"\bpause\b", r"\bspotify\b", r"\bchrome\b",
        r"\bbrightness\b", r"\bwifi\b",
    ]),
    (TaskClass.VISION, [
        r"\bwhat'?s on (my )?screen\b", r"\blook at\b", r"\bsee this\b",
        r"\bscreen\b", r"\bwebcam\b", r"\bcamera\b", r"\bread (the )?screen\b",
    ]),
    (TaskClass.CODE, [
        r"\bdebug\b", r"\bfix (this )?code\b", r"\btraceback\b",
        r"\btypeerror\b", r"\bsyntaxerror\b", r"\brefactor\b",
        r"\bwrite (a )?function\b", r"\bunit test\b",
    ]),
    (TaskClass.DEEP_RESEARCH, [
        r"\bdeep research\b", r"\bcomprehensive\b", r"\bin[- ]depth\b",
        r"\banalyze (all|every)\b", r"\bliterature review\b",
    ]),
    (TaskClass.RESEARCH, [
        r"\bresearch\b", r"\binvestigate\b", r"\bcompare\b",
        r"\bpros and cons\b", r"\bfind (out|sources)\b",
    ]),
    (TaskClass.SEARCH, [
        r"\bsearch\b", r"\bgoogle\b", r"\blook up\b", r"\bnews\b",
        r"\bwho is\b", r"\bwhat is\b", r"\bprice of\b",
    ]),
    (TaskClass.AGENT, [
        r"\bbuild\b", r"\bcreate (an? )?(app|project|website)\b",
        r"\bautomate\b", r"\bmulti[- ]step\b", r"\bhandle the boring\b",
        r"\bdelegate\b",
    ]),
]


def route(text: str) -> TaskClass:
    t = (text or "").strip().lower()
    if not t:
        return TaskClass.CONVERSATION
    # Very short conversational
    if len(t) < 24 and not any(k in t for k in ("open", "search", "build", "fix", "research")):
        if re.search(r"^(hi|hello|hey|thanks|thank you|ok|okay|yes|no|hmm)\b", t):
            return TaskClass.CONVERSATION
    for cls, patterns in _RULES:
        for pat in patterns:
            if re.search(pat, t, re.I):
                return cls
    # Default
    if len(t) > 200:
        return TaskClass.RESEARCH
    return TaskClass.CONVERSATION


def is_fast_path(text: str) -> bool:
    return route(text) in (TaskClass.FAST, TaskClass.SYSTEM)
