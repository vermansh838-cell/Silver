"""
SILVER Quiet Questions — non-spoken personal inquiry for the cognitive model.

Questions appear only in UI. Never spoken. Track history, avoid repeats,
prefer useful gaps in the personal model.
"""
from __future__ import annotations

import json
import random
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock
from typing import Optional

def _base() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

PATH = _base() / "memory" / "quiet_questions.json"
_lock = Lock()

# Seed bank — used only when personalization data is thin
_BANK = {
    "personal": [
        "What has been on your mind lately?",
        "What have you been enjoying recently?",
        "What are you looking forward to?",
        "What has been frustrating you lately?",
    ],
    "goals": [
        "What are you currently trying to get better at?",
        "What is one thing you want to accomplish this month?",
        "Which goal matters most to you right now?",
    ],
    "habits": [
        "What's one habit you've been trying to build?",
        "What usually helps you stay focused?",
        "What tends to break your momentum?",
    ],
    "learning": [
        "What topic are you most curious about right now?",
        "What concept are you struggling to understand?",
        "What would you like to become very good at?",
    ],
    "interests": [
        "What have you been interested in lately?",
        "What kind of things have been catching your attention?",
    ],
    "decisions": [
        "Is there a decision you've been thinking about?",
        "What trade-off are you dealing with right now?",
    ],
    "reflection": [
        "What went well for you recently?",
        "What is something you've learned about yourself recently?",
    ],
    "values": [
        "What matters more to you right now: speed or depth?",
        "What is something you don't want to compromise on?",
    ],
    "communication": [
        "What kind of explanation helps you understand something fastest?",
        "When you disagree with me, how direct should I be?",
    ],
}

_MIN_INTERVAL_SEC = 45 * 60  # at least 45 min between new questions
_SKIP_COOLDOWN_SEC = 3 * 60 * 60


def _empty() -> dict:
    return {
        "history": [],          # {q, category, ts, answer, skipped, related}
        "active": None,         # current unanswered {q, category, shown_at}
        "last_shown": None,
        "skip_streak": 0,
        "answer_streak": 0,
        "next_eligible": None,
    }


def load() -> dict:
    if not PATH.exists():
        return _empty()
    with _lock:
        try:
            data = json.loads(PATH.read_text(encoding="utf-8"))
            base = _empty()
            for k, v in base.items():
                if k not in data:
                    data[k] = v
            return data
        except Exception:
            return _empty()


def save(data: dict) -> None:
    with _lock:
        PATH.parent.mkdir(parents=True, exist_ok=True)
        PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _asked_texts(data: dict) -> set[str]:
    return {(h.get("q") or "").strip().lower() for h in data.get("history") or []}


def _context_hints() -> dict:
    hints = {"world": "General", "topic": "", "goals": [], "interests": []}
    try:
        from memory.intelligence_layer import load_layer, get_active_world, personal_model_summary
        layer = load_layer()
        hints["world"] = layer.get("active_world") or "General"
        w = (layer.get("worlds") or {}).get(hints["world"]) or {}
        hints["topic"] = w.get("topic") or ""
        hints["goals"] = list(w.get("goals") or [])[:4]
        # personal model keys as interest signals
        pm = layer.get("personal_model") or {}
        for cat in ("interests", "goals", "preferences", "habits"):
            items = pm.get(cat) or {}
            if isinstance(items, dict):
                hints["interests"].extend(list(items.keys())[:4])
    except Exception:
        pass
    return hints


def _generate_contextual(hints: dict, asked: set[str]) -> Optional[tuple[str, str]]:
    """Prefer a contextual question over generic bank."""
    world = (hints.get("world") or "").lower()
    topic = (hints.get("topic") or "").strip()
    candidates: list[tuple[str, str]] = []

    if topic and len(topic) > 3:
        candidates.append((
            f"What part of “{topic[:48]}” do you actually find most interesting?",
            "learning",
        ))
        candidates.append((
            f"Is there something about “{topic[:48]}” you still feel unsure about?",
            "learning",
        ))
    if world == "programming":
        candidates += [
            ("What kind of software do you most enjoy building?", "interests"),
            ("What part of programming feels most natural to you right now?", "learning"),
        ]
    elif world == "study":
        candidates += [
            ("What part of this subject do you actually find interesting?", "learning"),
            ("What would make studying feel less like a grind for you?", "habits"),
        ]
    elif world == "projects":
        candidates += [
            ("What part of your current project are you most satisfied with?", "reflection"),
            ("What do you want this project to become long-term?", "goals"),
        ]
    elif world == "personal":
        candidates += [
            ("What quality do you want more of in your day-to-day life?", "values"),
            ("What are you currently unsure about in a decision?", "decisions"),
        ]

    for g in hints.get("goals") or []:
        g = str(g)[:50]
        candidates.append((f"Has your priority around “{g}” shifted recently?", "goals"))

    random.shuffle(candidates)
    for q, cat in candidates:
        if q.lower() not in asked:
            return q, cat
    return None


def _pick_from_bank(asked: set[str]) -> Optional[tuple[str, str]]:
    cats = list(_BANK.keys())
    random.shuffle(cats)
    for cat in cats:
        opts = [q for q in _BANK[cat] if q.lower() not in asked]
        if opts:
            return random.choice(opts), cat
    return None


def should_show_question() -> bool:
    data = load()
    if data.get("active"):
        return True  # keep showing unanswered
    now = time.time()
    # respect cooldown after skips
    next_el = data.get("next_eligible")
    if next_el and now < float(next_el):
        return False
    last = data.get("last_shown")
    if last and now - float(last) < _MIN_INTERVAL_SEC:
        return False
    # if user skips a lot, back off harder
    if int(data.get("skip_streak") or 0) >= 3:
        if last and now - float(last) < _SKIP_COOLDOWN_SEC:
            return False
    return True


def get_active_question() -> Optional[dict]:
    data = load()
    return data.get("active")


def ensure_active_question() -> Optional[dict]:
    """Return current or create a new quiet question if eligible."""
    data = load()
    if data.get("active"):
        return data["active"]
    if not should_show_question():
        return None
    asked = _asked_texts(data)
    hints = _context_hints()
    picked = _generate_contextual(hints, asked) or _pick_from_bank(asked)
    if not picked:
        return None
    q, cat = picked
    active = {
        "q": q,
        "category": cat,
        "shown_at": datetime.now().isoformat(timespec="seconds"),
        "ts": time.time(),
    }
    data["active"] = active
    data["last_shown"] = time.time()
    save(data)
    return active


def skip_question() -> None:
    data = load()
    active = data.get("active")
    if not active:
        return
    data["history"].append({
        "q": active.get("q"),
        "category": active.get("category"),
        "ts": datetime.now().isoformat(timespec="seconds"),
        "answer": None,
        "skipped": True,
    })
    data["history"] = data["history"][-200:]
    data["active"] = None
    data["skip_streak"] = int(data.get("skip_streak") or 0) + 1
    data["answer_streak"] = 0
    data["next_eligible"] = time.time() + _MIN_INTERVAL_SEC * (1 + min(3, data["skip_streak"]))
    save(data)


def submit_answer(answer: str) -> dict:
    """
    Record answer, extract lightweight memories into intelligence_layer.
    Returns status dict for UI.
    """
    answer = (answer or "").strip()
    data = load()
    active = data.get("active")
    if not active or not answer:
        return {"ok": False, "status": "No active question"}

    entry = {
        "q": active.get("q"),
        "category": active.get("category"),
        "ts": datetime.now().isoformat(timespec="seconds"),
        "answer": answer[:800],
        "skipped": False,
    }
    data["history"].append(entry)
    data["history"] = data["history"][-200:]
    data["active"] = None
    data["skip_streak"] = 0
    data["answer_streak"] = int(data.get("answer_streak") or 0) + 1
    data["next_eligible"] = time.time() + _MIN_INTERVAL_SEC
    save(data)

    # Learn into personal model
    learned = _learn_from_answer(active.get("category") or "personal", active.get("q") or "", answer)
    return {"ok": True, "status": "Memory updated" if learned else "Answer received", "learned": learned}


def _learn_from_answer(category: str, question: str, answer: str) -> list[str]:
    learned = []
    if len(answer) < 4:
        return learned
    try:
        from memory.intelligence_layer import remember
        # Map quiet categories → personal model categories
        cat_map = {
            "personal": "preferences",
            "goals": "goals",
            "habits": "habits",
            "learning": "interests",
            "interests": "interests",
            "decisions": "values",
            "reflection": "preferences",
            "values": "values",
            "communication": "preferences",
        }
        pm_cat = cat_map.get(category, "notes")
        # key from question snippet
        key = question.lower().replace("?", "").strip()[:48] or "quiet_insight"
        key = "qq_" + "".join(c if c.isalnum() or c in " _-" else "_" for c in key)[:40]
        remember(
            pm_cat,
            key,
            answer[:280],
            source="quiet_question",
            confidence=0.65,
            importance=0.55,
        )
        learned.append(f"{pm_cat}:{key}")
        # Future-self goals
        if category == "goals" and len(answer) > 12:
            try:
                from memory.intelligence_layer import get_future_self, update_future_self
                fs = get_future_self()
                goals = list(fs.get("goals") or [])
                snippet = answer[:80]
                if snippet not in goals:
                    goals = ([snippet] + goals)[:12]
                    update_future_self(goals=goals)
            except Exception:
                pass
    except Exception:
        pass
    return learned
