"""
E.V. Agent Control Tower

Lifecycle:
  IDLE → SPAWNED → WORKING → WAITING_FOR_USER → COMPLETED
                                 ↘ FAILED / CANCELLED

WAITING_FOR_USER is the critical bridge between autonomy and attention.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from threading import Lock
from typing import Any, Callable, Optional


class AgentState(str, Enum):
    IDLE = "IDLE"
    SPAWNED = "SPAWNED"
    WORKING = "WORKING"
    WAITING_FOR_USER = "WAITING_FOR_USER"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


@dataclass
class AgentRecord:
    id: str
    name: str
    purpose: str = ""
    state: AgentState = AgentState.IDLE
    current_task: str = ""
    progress: float = 0.0              # 0..1
    elapsed_s: float = 0.0
    last_action: str = ""
    next_action: str = ""
    needs_attention: bool = False
    attention_reason: str = ""
    started_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["state"] = self.state.value if isinstance(self.state, AgentState) else self.state
        return d


class AgentTower:
    def __init__(self):
        self._lock = Lock()
        self._agents: dict[str, AgentRecord] = {}
        self._listeners: list[Callable[[list[AgentRecord]], None]] = []

    def on_change(self, cb: Callable[[list[AgentRecord]], None]):
        self._listeners.append(cb)

    def _notify(self):
        agents = self.list()
        for cb in self._listeners:
            try:
                cb(agents)
            except Exception:
                pass

    def spawn(self, name: str, purpose: str = "", **meta) -> AgentRecord:
        aid = str(uuid.uuid4())[:8]
        rec = AgentRecord(
            id=aid,
            name=name,
            purpose=purpose,
            state=AgentState.SPAWNED,
            meta=meta,
        )
        with self._lock:
            self._agents[aid] = rec
        self._notify()
        return rec

    def get(self, agent_id: str) -> Optional[AgentRecord]:
        with self._lock:
            return self._agents.get(agent_id)

    def list(self) -> list[AgentRecord]:
        with self._lock:
            return list(self._agents.values())

    def needing_attention(self) -> list[AgentRecord]:
        with self._lock:
            return [a for a in self._agents.values() if a.needs_attention or a.state == AgentState.WAITING_FOR_USER]

    def update(
        self,
        agent_id: str,
        *,
        state: AgentState | str | None = None,
        current_task: str | None = None,
        progress: float | None = None,
        last_action: str | None = None,
        next_action: str | None = None,
        needs_attention: bool | None = None,
        attention_reason: str | None = None,
    ) -> Optional[AgentRecord]:
        with self._lock:
            rec = self._agents.get(agent_id)
            if not rec:
                return None
            if state is not None:
                if isinstance(state, str):
                    state = AgentState(state)
                rec.state = state
                if state == AgentState.WAITING_FOR_USER:
                    rec.needs_attention = True
            if current_task is not None:
                rec.current_task = current_task
            if progress is not None:
                rec.progress = max(0.0, min(1.0, progress))
            if last_action is not None:
                rec.last_action = last_action
            if next_action is not None:
                rec.next_action = next_action
            if needs_attention is not None:
                rec.needs_attention = needs_attention
            if attention_reason is not None:
                rec.attention_reason = attention_reason
            rec.updated_at = time.time()
            rec.elapsed_s = rec.updated_at - rec.started_at
        self._notify()
        return rec

    def set_working(self, agent_id: str, task: str, progress: float = 0.0):
        return self.update(
            agent_id,
            state=AgentState.WORKING,
            current_task=task,
            progress=progress,
            needs_attention=False,
        )

    def wait_for_user(self, agent_id: str, reason: str):
        return self.update(
            agent_id,
            state=AgentState.WAITING_FOR_USER,
            needs_attention=True,
            attention_reason=reason,
            next_action="Awaiting user",
        )

    def complete(self, agent_id: str, last_action: str = "Done"):
        return self.update(
            agent_id,
            state=AgentState.COMPLETED,
            progress=1.0,
            last_action=last_action,
            needs_attention=False,
        )

    def fail(self, agent_id: str, reason: str = ""):
        return self.update(
            agent_id,
            state=AgentState.FAILED,
            last_action=reason or "Failed",
            needs_attention=True,
            attention_reason=reason,
        )

    def cancel(self, agent_id: str):
        return self.update(
            agent_id,
            state=AgentState.CANCELLED,
            needs_attention=False,
        )

    def archive_finished(self):
        """Remove COMPLETED / CANCELLED agents older than a few minutes."""
        now = time.time()
        with self._lock:
            self._agents = {
                k: v for k, v in self._agents.items()
                if v.state not in (AgentState.COMPLETED, AgentState.CANCELLED)
                or (now - v.updated_at) < 180
            }
        self._notify()

    def summary_lines(self) -> list[str]:
        """Human-readable lines for the HUD."""
        lines = []
        for a in self.list():
            flag = " ⚠" if a.needs_attention else ""
            prog = f" {int(a.progress * 100)}%" if a.state == AgentState.WORKING else ""
            task = f" — {a.current_task}" if a.current_task else ""
            lines.append(f"● {a.name}  {a.state.value}{prog}{flag}{task}")
        return lines or ["No active agents"]


# Seed default monitors as IDLE agents (display only until real work starts)
def seed_default_agents(tower: AgentTower) -> None:
    if tower.list():
        return
    for name, purpose in (
        ("Project Monitor", "Watch active project activity"),
        ("Calendar Watcher", "Meeting and deadline awareness"),
        ("System Monitor", "Health and anomaly detection"),
    ):
        rec = tower.spawn(name, purpose)
        tower.update(rec.id, state=AgentState.IDLE)


tower = AgentTower()
