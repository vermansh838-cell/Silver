"""
SILVER intelligence layer — context worlds, evolving personal model,
future-self, execution history, current focus.

Architectural coherence layer. Does not replace memory_manager;
extends it with structured metadata and session context.
"""
from __future__ import annotations

import json
import sys
import time
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any

def _base() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

BASE = _base()
LAYER_PATH = BASE / "memory" / "intelligence_layer.json"
_lock = Lock()

WORLDS = (
    "General", "Personal", "Study", "Programming",
    "Projects", "Research", "Ideas",
)

_DEFAULT = {
    "active_world": "General",
    "worlds": {
        w: {
            "topic": "",
            "active_files": [],
            "recent_threads": [],
            "goals": [],
            "tasks": [],
            "notes": "",
            "updated": None,
        } for w in WORLDS
    },
    "personal_model": {
        # category -> key -> entry
        # entry: {value, source, confidence, importance, category, created, last_confirmed}
    },
    "future_self": {
        "current_self": "",
        "goals": [],
        "desired_capabilities": [],
        "long_term_projects": [],
        "standards": [],
        "direction": "",
        "updated": None,
    },
    "execution_history": [],  # max ~80 recent
    "current_focus": {
        "label": "",
        "detail": "",
        "suggested_action": "",
        "dismissed": False,
        "updated": None,
    },
    "personalization": {
        "response_depth": "balanced",
        "humor": "light",
        "hinglish": "auto",
        "challenge_level": "moderate",
        "proactivity": "low",
        "format_preference": "structured",
    },
}


def _empty() -> dict:
    return json.loads(json.dumps(_DEFAULT))


def load_layer() -> dict:
    if not LAYER_PATH.exists():
        return _empty()
    with _lock:
        try:
            data = json.loads(LAYER_PATH.read_text(encoding="utf-8"))
            base = _empty()
            if not isinstance(data, dict):
                return base
            for k, v in base.items():
                if k not in data:
                    data[k] = v
            return data
        except Exception:
            return _empty()


def save_layer(data: dict) -> None:
    with _lock:
        LAYER_PATH.parent.mkdir(parents=True, exist_ok=True)
        LAYER_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# ── Context worlds ───────────────────────────────────────────────────────────

def get_active_world() -> str:
    return load_layer().get("active_world") or "General"


def set_active_world(world: str) -> str:
    data = load_layer()
    w = world if world in WORLDS else "General"
    data["active_world"] = w
    data["worlds"].setdefault(w, _empty()["worlds"]["General"])
    data["worlds"][w]["updated"] = datetime.now().isoformat(timespec="seconds")
    save_layer(data)
    return w


def update_world(world: str | None = None, **fields) -> dict:
    data = load_layer()
    w = world or data.get("active_world") or "General"
    if w not in data["worlds"]:
        data["worlds"][w] = _empty()["worlds"]["General"]
    slot = data["worlds"][w]
    for k, v in fields.items():
        if k in slot:
            slot[k] = v
    slot["updated"] = datetime.now().isoformat(timespec="seconds")
    save_layer(data)
    return slot


def detect_world_from_text(text: str) -> str | None:
    t = (text or "").lower()
    rules = [
        ("Programming", ("code", "python", "c++", "javascript", "bug", "function", "api", "git", "compile", "debug")),
        ("Study", ("study", "exam", "chapter", "revise", "homework", "lecture", "notes", "physics", "math", "biology")),
        ("Research", ("research", "paper", "paper on", "literature", "hypothesis", "survey")),
        ("Projects", ("project", "ship", "milestone", "roadmap", "build silver", "feature")),
        ("Ideas", ("idea", "brainstorm", "what if", "concept for")),
        ("Personal", ("i feel", "my life", "relationship", "family", "habit", "health", "sleep")),
    ]
    for world, keys in rules:
        if any(k in t for k in keys):
            return world
    return None


def context_label() -> str:
    data = load_layer()
    w = data.get("active_world") or "General"
    topic = (data.get("worlds", {}).get(w, {}) or {}).get("topic") or ""
    if topic:
        return f"{w.upper()} · {topic.upper()}"
    return w.upper()


# ── Evolving personal model ──────────────────────────────────────────────────

def remember(
    category: str,
    key: str,
    value: str,
    *,
    source: str = "conversation",
    confidence: float = 0.7,
    importance: float = 0.5,
) -> dict:
    """Store or update a personal-model entry with conflict awareness."""
    data = load_layer()
    pm = data.setdefault("personal_model", {})
    cat = pm.setdefault(category, {})
    now = datetime.now().isoformat(timespec="seconds")
    old = cat.get(key)
    entry = {
        "value": value,
        "source": source,
        "confidence": max(0.0, min(1.0, confidence)),
        "importance": max(0.0, min(1.0, importance)),
        "category": category,
        "created": (old or {}).get("created", now),
        "last_confirmed": now,
        "previous": None,
    }
    if old and isinstance(old, dict) and old.get("value") and old["value"] != value:
        # Keep previous for revision reasoning — do not blindly dual-store
        entry["previous"] = {
            "value": old.get("value"),
            "confidence": old.get("confidence"),
            "last_confirmed": old.get("last_confirmed"),
        }
        # New explicit statement gets higher confidence bump
        entry["confidence"] = max(entry["confidence"], 0.75)
    cat[key] = entry
    save_layer(data)
    return entry


def personal_model_summary(max_items: int = 24) -> str:
    data = load_layer()
    pm = data.get("personal_model") or {}
    lines = []
    for cat, items in pm.items():
        if not isinstance(items, dict):
            continue
        for key, entry in list(items.items())[:8]:
            if not isinstance(entry, dict):
                continue
            conf = entry.get("confidence", 0.5)
            if conf < 0.35:
                continue
            lines.append(f"- [{cat}] {key}: {entry.get('value')} (conf={conf:.2f})")
            if len(lines) >= max_items:
                break
        if len(lines) >= max_items:
            break
    return "\n".join(lines) if lines else ""


# ── Future self ──────────────────────────────────────────────────────────────

def get_future_self() -> dict:
    return load_layer().get("future_self") or _empty()["future_self"]


def update_future_self(**fields) -> dict:
    data = load_layer()
    fs = data.setdefault("future_self", _empty()["future_self"])
    for k, v in fields.items():
        if k in fs:
            fs[k] = v
    fs["updated"] = datetime.now().isoformat(timespec="seconds")
    save_layer(data)
    return fs


def future_self_prompt_block() -> str:
    fs = get_future_self()
    parts = []
    if fs.get("direction"):
        parts.append(f"Direction: {fs['direction']}")
    if fs.get("goals"):
        parts.append("Goals: " + "; ".join(fs["goals"][:6]))
    if fs.get("standards"):
        parts.append("Standards: " + "; ".join(fs["standards"][:4]))
    if fs.get("desired_capabilities"):
        parts.append("Desired capabilities: " + "; ".join(fs["desired_capabilities"][:4]))
    if not parts:
        return ""
    return "FUTURE SELF MODEL\n" + "\n".join(parts)


# ── Execution history ────────────────────────────────────────────────────────

_VALID_STATUS = {
    "PLANNED", "WAITING FOR APPROVAL", "EXECUTING",
    "COMPLETE", "FAILED", "CANCELLED", "UNDONE",
}


def log_execution(
    action: str,
    status: str = "COMPLETE",
    result: str = "",
    risk: str = "low",
) -> dict:
    data = load_layer()
    hist = data.setdefault("execution_history", [])
    st = status.upper() if status.upper() in _VALID_STATUS else "COMPLETE"
    entry = {
        "action": action[:200],
        "status": st,
        "result": (result or "")[:300],
        "risk": risk,
        "time": datetime.now().isoformat(timespec="seconds"),
        "ts": time.time(),
    }
    hist.insert(0, entry)
    data["execution_history"] = hist[:80]
    save_layer(data)
    return entry


def recent_executions(n: int = 12) -> list[dict]:
    return (load_layer().get("execution_history") or [])[:n]


# ── Current focus ────────────────────────────────────────────────────────────

def set_focus(label: str, detail: str = "", suggested_action: str = "") -> dict:
    data = load_layer()
    data["current_focus"] = {
        "label": label[:80],
        "detail": detail[:200],
        "suggested_action": suggested_action[:200],
        "dismissed": False,
        "updated": datetime.now().isoformat(timespec="seconds"),
    }
    save_layer(data)
    return data["current_focus"]


def dismiss_focus() -> None:
    data = load_layer()
    cf = data.setdefault("current_focus", {})
    cf["dismissed"] = True
    save_layer(data)


def get_focus() -> dict:
    cf = load_layer().get("current_focus") or {}
    if cf.get("dismissed"):
        return {}
    return cf if cf.get("label") else {}


# ── Prompt injection ─────────────────────────────────────────────────────────

def intelligence_prompt_block() -> str:
    """Compact block for system prompt / session context."""
    data = load_layer()
    lines = [
        f"ACTIVE CONTEXT WORLD: {data.get('active_world', 'General')}",
        f"CONTEXT LABEL: {context_label()}",
    ]
    w = data.get("worlds", {}).get(data.get("active_world") or "General", {})
    if w.get("topic"):
        lines.append(f"Current topic: {w['topic']}")
    if w.get("goals"):
        lines.append("World goals: " + "; ".join(w["goals"][:4]))
    cf = get_focus()
    if cf.get("label"):
        lines.append(f"CURRENT FOCUS: {cf['label']}")
        if cf.get("detail"):
            lines.append(f"  {cf['detail']}")
        if cf.get("suggested_action"):
            lines.append(f"  Suggested: {cf['suggested_action']}")
    fs = future_self_prompt_block()
    if fs:
        lines.append(fs)
    pm = personal_model_summary(12)
    if pm:
        lines.append("PERSONAL MODEL (high-confidence):")
        lines.append(pm)
    pers = data.get("personalization") or {}
    if pers:
        lines.append(
            "Personalization hints: "
            f"depth={pers.get('response_depth')}, "
            f"challenge={pers.get('challenge_level')}, "
            f"format={pers.get('format_preference')}"
        )
    lines.append(
        "Decision support: when advising, identify the decision, assumptions, "
        "missing info, short/long-term consequences, alternatives, trade-offs. "
        "Compare actions to FUTURE SELF when relevant. Disagree when reasoning is weak. "
        "Never fabricate personal facts."
    )
    lines.append(
        "Actions: for medium/high risk, describe an ACTION PLAN with risk level "
        "and wait for approval. Log operational status only — never chain-of-thought."
    )
    return "\n".join(lines)
