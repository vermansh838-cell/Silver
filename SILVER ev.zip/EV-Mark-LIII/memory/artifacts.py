"""
E.V. Dynamic Artifact System

Artifacts materialize in the center workspace only when useful.
They are dismissible and context-aware — not permanent widgets.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from threading import Lock
from typing import Any, Callable, Optional


class ArtifactKind(str, Enum):
    RESEARCH_BRIEF = "RESEARCH_BRIEF"
    SEARCH_RESULTS = "SEARCH_RESULTS"
    CODE_ERROR = "CODE_ERROR"
    CODE_DIFF = "CODE_DIFF"
    FILE_PREVIEW = "FILE_PREVIEW"
    CALENDAR_PLAN = "CALENDAR_PLAN"
    MEETING_NOTES = "MEETING_NOTES"
    TASK_PLAN = "TASK_PLAN"
    AGENT_PROGRESS = "AGENT_PROGRESS"
    SYSTEM_ALERT = "SYSTEM_ALERT"
    MEDIA = "MEDIA"
    MAP = "MAP"
    COMPARISON = "COMPARISON"
    DECISION_CARD = "DECISION_CARD"
    APPROVAL_CARD = "APPROVAL_CARD"
    GENERIC = "GENERIC"


@dataclass
class ArtifactAction:
    id: str
    label: str
    primary: bool = False


@dataclass
class Artifact:
    id: str
    kind: ArtifactKind
    title: str
    body: str = ""
    meta: dict = field(default_factory=dict)   # confidence, sources, line, etc.
    actions: list[ArtifactAction] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    sticky: bool = False                       # if True, don't auto-dismiss
    source_event_id: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["kind"] = self.kind.value if isinstance(self.kind, ArtifactKind) else self.kind
        return d


class ArtifactWorkspace:
    """
    Holds the single active artifact (or a short stack).
    UI subscribes via on_change callbacks.
    """

    def __init__(self, max_stack: int = 3):
        self._lock = Lock()
        self._stack: list[Artifact] = []
        self._max = max_stack
        self._listeners: list[Callable[[Optional[Artifact]], None]] = []

    def on_change(self, cb: Callable[[Optional[Artifact]], None]):
        self._listeners.append(cb)

    def _notify(self):
        current = self.current()
        for cb in self._listeners:
            try:
                cb(current)
            except Exception:
                pass

    def current(self) -> Optional[Artifact]:
        with self._lock:
            return self._stack[-1] if self._stack else None

    def push(self, artifact: Artifact) -> Artifact:
        with self._lock:
            # Replace same-kind non-sticky if present
            self._stack = [
                a for a in self._stack
                if a.sticky or a.kind != artifact.kind
            ]
            self._stack.append(artifact)
            if len(self._stack) > self._max:
                # drop oldest non-sticky
                for i, a in enumerate(self._stack):
                    if not a.sticky:
                        self._stack.pop(i)
                        break
        self._notify()
        return artifact

    def dismiss(self, artifact_id: str | None = None):
        with self._lock:
            if artifact_id is None:
                if self._stack:
                    self._stack.pop()
            else:
                self._stack = [a for a in self._stack if a.id != artifact_id]
        self._notify()

    def clear(self):
        with self._lock:
            self._stack.clear()
        self._notify()


def make_artifact(
    kind: ArtifactKind | str,
    title: str,
    body: str = "",
    *,
    meta: dict | None = None,
    actions: list[tuple[str, str, bool]] | None = None,
    sticky: bool = False,
    source_event_id: str = "",
) -> Artifact:
    """
    actions: list of (id, label, primary?)
    """
    if isinstance(kind, str):
        try:
            kind = ArtifactKind(kind)
        except ValueError:
            kind = ArtifactKind.GENERIC
    acts = [
        ArtifactAction(id=a[0], label=a[1], primary=bool(a[2]) if len(a) > 2 else False)
        for a in (actions or [])
    ]
    return Artifact(
        id=str(uuid.uuid4())[:8],
        kind=kind,
        title=title,
        body=body,
        meta=meta or {},
        actions=acts,
        sticky=sticky,
        source_event_id=source_event_id,
    )


# Helpers for common artifacts
def research_brief(title: str, findings: list[str], sources: int = 0, confidence: str = "MEDIUM") -> Artifact:
    body = "\n".join(f"• {f}" for f in findings)
    return make_artifact(
        ArtifactKind.RESEARCH_BRIEF,
        title,
        body,
        meta={"sources": sources, "confidence": confidence},
        actions=[
            ("open", "OPEN REPORT", True),
            ("save", "SAVE", False),
            ("dismiss", "DISMISS", False),
        ],
    )


def code_error(file: str, line: int, error: str, cause: str = "") -> Artifact:
    body = f"{file}\nLine {line}\n\n{error}"
    if cause:
        body += f"\n\nLikely: {cause}"
    return make_artifact(
        ArtifactKind.CODE_ERROR,
        "BUILD FAILED",
        body,
        meta={"file": file, "line": line},
        actions=[
            ("inspect", "INSPECT", True),
            ("fix", "FIX", False),
            ("open", "OPEN FILE", False),
        ],
    )


def decision_card(title: str, question: str, options: list[str]) -> Artifact:
    body = question + "\n\n" + "\n".join(f"→ {o}" for o in options)
    return make_artifact(
        ArtifactKind.DECISION_CARD,
        title,
        body,
        actions=[(f"opt_{i}", o, i == 0) for i, o in enumerate(options)]
        + [("dismiss", "LATER", False)],
    )


def approval_card(title: str, reason: str, action_id: str = "") -> Artifact:
    return make_artifact(
        ArtifactKind.APPROVAL_CARD,
        title,
        f"E.V. reason: {reason}",
        meta={"action_id": action_id},
        actions=[
            ("allow", "ALLOW", True),
            ("deny", "DENY", False),
        ],
        sticky=True,
    )


# Process-wide workspace
workspace = ArtifactWorkspace()
