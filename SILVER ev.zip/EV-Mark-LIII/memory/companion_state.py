"""
E.V. companion state: relationships, goals, rituals, mood.
Persisted under memory/companion.json
"""
from __future__ import annotations
import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock
import sys

def _base() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

PATH = _base() / "memory" / "companion.json"
_lock = Lock()

def _empty():
    return {
        "relationships": [
            # {"name": "Mom", "last_days": 10, "note": "Call soon", "status": "ok"}
        ],
        "goals": [
            # {"title": "Morning ritual", "progress": 100, "streak": 12, "target": 100, "unit": "%"}
        ],
        "rituals": [
            # {"title": "Morning coffee + planning", "time": "06:30", "enabled": True, "streak": 0}
        ],
        "mood": "Calm",
        "updated_at": None,
    }

_DEMO_GOAL_TITLES = {"morning ritual", "fitness", "learning"}
_DEMO_REL_NAMES = {"mom", "sarah"}
_DEMO_TIMELINE_TITLES = {
    "deep work block", "meetings / calls", "meetings/calls",
    "project time", "wrap-up & review", "wrap-up and review",
}

def _strip_demo(data: dict) -> dict:
    """Remove shipped demo placeholders so only real user data remains."""
    goals = []
    for g in data.get("goals") or []:
        title = str(g.get("title") or "").strip().lower()
        if title in _DEMO_GOAL_TITLES:
            continue
        goals.append(g)
    data["goals"] = goals

    rels = []
    for r in data.get("relationships") or []:
        name = str(r.get("name") or "").strip().lower()
        if name in _DEMO_REL_NAMES:
            continue
        rels.append(r)
    data["relationships"] = rels

    tl = []
    for it in data.get("timeline") or []:
        title = str(it.get("title") or "").strip().lower()
        if title in _DEMO_TIMELINE_TITLES:
            continue
        # also drop the classic seeded ids
        if str(it.get("id") or "") in {"t1", "t2", "t3", "t4"}:
            continue
        tl.append(it)
    data["timeline"] = tl

    # demo rituals with fixed times/titles
    rituals = []
    for r in data.get("rituals") or []:
        title = str(r.get("title") or "").strip().lower()
        if title in {"morning coffee + planning", "evening review"}:
            continue
        rituals.append(r)
    data["rituals"] = rituals
    return data

def load() -> dict:
    with _lock:
        if not PATH.exists():
            data = _empty()
            data["mood"] = _compute_mood()
            _save_unlocked(data)
            return data
        try:
            data = json.loads(PATH.read_text(encoding="utf-8"))
            for k, v in _empty().items():
                data.setdefault(k, v)
            cleaned = _strip_demo(data)
            # persist cleanup once so UI never sees demo again
            if cleaned != data:
                _save_unlocked(cleaned)
            return cleaned
        except Exception:
            return _empty()


def _save_unlocked(data: dict) -> None:
    PATH.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = datetime.now().isoformat(timespec="seconds")
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, PATH)

def save(data: dict) -> None:
    with _lock:
        _save_unlocked(data)

def _compute_mood() -> str:
    h = datetime.now().hour
    if 5 <= h < 11:
        return "Energized"
    if 11 <= h < 17:
        return "Focused"
    if 17 <= h < 21:
        return "Thoughtful"
    return "Calm"

def get_mood() -> str:
    data = load()
    data["mood"] = _compute_mood()
    save(data)
    return data["mood"]

def list_relationships() -> list:
    return list(load().get("relationships") or [])

def list_goals() -> list:
    return list(load().get("goals") or [])

def list_rituals() -> list:
    return list(load().get("rituals") or [])

def upsert_relationship(name: str, note: str = "", status: str = "ok", last_days: int = 0) -> dict:
    data = load()
    rels = data.setdefault("relationships", [])
    for r in rels:
        if r.get("name", "").lower() == name.lower():
            r["note"] = note or r.get("note", "")
            r["status"] = status or r.get("status", "ok")
            r["last_days"] = last_days
            save(data)
            return r
    rec = {"name": name, "note": note, "status": status, "last_days": last_days}
    rels.append(rec)
    save(data)
    return rec

def upsert_goal(title: str, progress: float = 0, streak: int = 0, target: float = 100, unit: str = "%") -> dict:
    data = load()
    goals = data.setdefault("goals", [])
    for g in goals:
        if g.get("title", "").lower() == title.lower():
            g["progress"] = progress
            g["streak"] = streak
            g["target"] = target
            g["unit"] = unit
            save(data)
            return g
    rec = {"title": title, "progress": progress, "streak": streak, "target": target, "unit": unit}
    goals.append(rec)
    save(data)
    return rec

def bump_goal(title: str, delta: float = 5) -> dict | None:
    data = load()
    for g in data.get("goals") or []:
        if g.get("title", "").lower() == title.lower():
            g["progress"] = min(float(g.get("target") or 100), float(g.get("progress") or 0) + delta)
            if g["progress"] >= float(g.get("target") or 100):
                g["streak"] = int(g.get("streak") or 0) + 1
            save(data)
            return g
    return None

def due_rituals(within_minutes: int = 30) -> list:
    """Rituals whose HH:MM is within the next `within_minutes`."""
    now = datetime.now()
    out = []
    for r in list_rituals():
        if not r.get("enabled", True):
            continue
        try:
            hh, mm = map(int, str(r.get("time") or "00:00").split(":")[:2])
            target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if target < now:
                target += timedelta(days=1)
            delta = (target - now).total_seconds() / 60.0
            if 0 <= delta <= within_minutes:
                out.append({**r, "minutes_until": int(delta)})
        except Exception:
            pass
    return out



# ── Energy budget ──────────────────────────────────────────────────────────
def get_energy() -> dict:
    data = load()
    e = data.setdefault("energy", {
        "focus_hours_used": 0.0,
        "focus_hours_budget": 5.0,
        "date": datetime.now().strftime("%Y-%m-%d"),
    })
    today = datetime.now().strftime("%Y-%m-%d")
    if e.get("date") != today:
        e["focus_hours_used"] = 0.0
        e["date"] = today
        data["energy"] = e
        save(data)
    return e

def add_focus_minutes(minutes: float) -> dict:
    data = load()
    e = get_energy()
    e["focus_hours_used"] = float(e.get("focus_hours_used") or 0) + max(0, minutes) / 60.0
    data["energy"] = e
    save(data)
    return e

def energy_warning() -> str | None:
    e = get_energy()
    used = float(e.get("focus_hours_used") or 0)
    budget = float(e.get("focus_hours_budget") or 5)
    if used >= budget:
        return f"Focus budget used ({used:.1f}/{budget:.0f}h). Protect rest of day."
    if used >= budget * 0.8:
        return f"Focus budget ~{int(100*used/budget)}% used ({used:.1f}/{budget:.0f}h)."
    return None

# ── Timeline (work mode) ───────────────────────────────────────────────────
def list_timeline() -> list:
    """Return only user-set timeline items (empty until the user asks Silver to plan the day)."""
    data = load()
    return list(data.get("timeline") or [])

def update_timeline_item(item_id: str, **fields) -> dict | None:
    data = load()
    for it in data.get("timeline") or []:
        if it.get("id") == item_id:
            it.update({k: v for k, v in fields.items() if v is not None})
            save(data)
            return it
    return None

def add_timeline_item(time: str, title: str, kind: str = "task") -> dict:
    data = load()
    items = data.setdefault("timeline", [])
    import uuid
    rec = {"id": f"t-{uuid.uuid4().hex[:6]}", "time": time, "title": title, "kind": kind, "done": False}
    items.append(rec)
    items.sort(key=lambda x: x.get("time") or "")
    save(data)
    return rec

# ── Auto person tagging from chat text ─────────────────────────────────────
_STOP = {
    "i", "me", "my", "we", "you", "he", "she", "they", "the", "a", "an", "and", "or",
    "ansh", "ev", "e.v", "jarvis", "today", "tomorrow", "monday", "sir", "bro",
}

def extract_people_mentions(text: str) -> list[str]:
    """Heuristic: capitalized tokens / common relationship words."""
    if not text:
        return []
    import re
    found = []
    # explicit patterns
    for m in re.findfindall(r"\b(?:my|with|call|text|message|meet)\s+([A-Z][a-z]{2,})\b", text) if False else []:
        pass
    patterns = [
        r"\b(?:my|with|call|text|message|ping|meet)\s+([A-Z][a-z]{2,})\b",
        r"\b([A-Z][a-z]{2,})\s+(?:said|told|asked|called|messaged)\b",
        r"\b(?:mom|mum|dad|mama|papa|bro|sis|boss|manager)\b",
    ]
    low = text
    for pat in patterns:
        for m in re.finditer(pat, text, flags=re.IGNORECASE):
            name = m.group(1) if m.lastindex else m.group(0)
            name = name.strip().title()
            if name.lower() in _STOP:
                continue
            # normalize family
            alias = {"Mom": "Mom", "Mum": "Mom", "Mama": "Mom", "Dad": "Dad", "Papa": "Dad",
                     "Boss": "Manager", "Manager": "Manager"}
            name = alias.get(name, name)
            if name not in found:
                found.append(name)
    return found

def note_people_from_text(text: str) -> list:
    """Update relationship last_days=0 when mentioned."""
    names = extract_people_mentions(text)
    out = []
    for n in names:
        out.append(upsert_relationship(n, note="Mentioned in chat", status="ok", last_days=0))
    return out

# ── Anticipatory briefing hints ────────────────────────────────────────────
def anticipatory_hints() -> list[str]:
    hints = []
    now = datetime.now()
    if now.weekday() == 0:  # Monday
        hints.append("Monday load: protect a deep-work block before meetings stack up.")
    if now.weekday() == 4:
        hints.append("Friday: good day to close loops and note wins for the week.")
    w = energy_warning()
    if w:
        hints.append(w)
    for r in due_rituals(20):
        hints.append(f"Ritual '{r.get('title')}' starts in ~{r.get('minutes_until')} min.")
    for rel in list_relationships():
        days = int(rel.get("last_days") or 0)
        if days >= 7:
            hints.append(f"Haven't connected with {rel.get('name')} in ~{days} days.")
    for g in list_goals():
        prog = float(g.get("progress") or 0)
        target = float(g.get("target") or 100) or 100
        if prog >= target:
            hints.append(f"Goal complete: {g.get('title')} — celebrate or raise the bar.")
    return hints[:6]

def context_for_prompt() -> str:
    """Compact block for Gemini system context."""
    data = load()
    lines = ["[COMPANION STATE]"]
    lines.append(f"E.V. mood: {data.get('mood') or _compute_mood()}")
    e = get_energy()
    lines.append(
        f"Focus energy: {float(e.get('focus_hours_used') or 0):.1f}/"
        f"{float(e.get('focus_hours_budget') or 5):.0f}h today"
    )
    rels = data.get("relationships") or []
    if rels:
        lines.append("Relationships:")
        for r in rels[:8]:
            lines.append(
                f"- {r.get('name')}: last ~{r.get('last_days', '?')}d | {r.get('note') or ''} [{r.get('status') or 'ok'}]"
            )
    goals = data.get("goals") or []
    if goals:
        lines.append("Goals:")
        for g in goals[:8]:
            lines.append(
                f"- {g.get('title')}: {g.get('progress')}/{g.get('target')}{g.get('unit') or ''} streak {g.get('streak') or 0}"
            )
    rituals = data.get("rituals") or []
    if rituals:
        lines.append("Rituals:")
        for r in rituals[:6]:
            lines.append(f"- {r.get('title')} @ {r.get('time')} streak {r.get('streak') or 0}")
    due = due_rituals(45)
    if due:
        lines.append("Due soon:")
        for r in due:
            lines.append(f"- {r.get('title')} in ~{r.get('minutes_until')} min")
    tl = list_timeline()
    if tl:
        lines.append("Today timeline:")
        for it in tl[:8]:
            mark = "✓" if it.get("done") else "·"
            lines.append(f"  {mark} {it.get('time')} {it.get('title')} ({it.get('kind')})")
    hints = anticipatory_hints()
    if hints:
        lines.append("Anticipatory:")
        for h in hints:
            lines.append(f"- {h}")
    return "\n".join(lines)
