"""
E.V. Attention Broker — first-class orchestration layer.

Every event is scored, then routed to:
  SILENT | PASSIVE | SURFACE | SPEAK | INTERRUPT

Never interrupt merely because we can.
WHY_NOW is internal classification only — never chain-of-thought dump.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from threading import Lock
from typing import Any, Callable, Optional


class Surface(str, Enum):
    SILENT = "SILENT"
    PASSIVE = "PASSIVE"
    SURFACE = "SURFACE"
    SPEAK = "SPEAK"
    INTERRUPT = "INTERRUPT"


class WhyNow(str, Enum):
    DEADLINE = "deadline"
    ANOMALY = "anomaly"
    OPPORTUNITY = "opportunity"
    USER_REQUEST = "user_request"
    AGENT_BLOCKED = "agent_blocked"
    REMINDER = "reminder"
    SAFETY = "safety"
    ROUTINE = "routine"
    UNKNOWN = "unknown"


@dataclass
class AttentionEvent:
    id: str
    kind: str                          # e.g. calendar, build, email, agent, system
    title: str
    detail: str = ""
    relevance: float = 0.5             # 0..1
    urgency: float = 0.5               # 0..1
    confidence: float = 0.7            # 0..1
    actionability: float = 0.5         # 0..1
    user_attention_cost: float = 0.5   # 0..1  (higher = more costly)
    interruption_allowed: bool = True
    why_now: WhyNow = WhyNow.UNKNOWN
    suggested_surface: Optional[Surface] = None
    payload: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    decided_surface: Optional[Surface] = None
    handled: bool = False


# Heuristic thresholds (tunable)
_SPEAK_SCORE = 0.72
_SURFACE_SCORE = 0.48
_PASSIVE_SCORE = 0.28
_INTERRUPT_FLOOR = 0.88  # only with safety / agent_blocked / high urgency


def _score(ev: AttentionEvent) -> float:
    """Weighted composite. Higher user_attention_cost lowers willingness to interrupt."""
    return (
        0.30 * ev.relevance
        + 0.30 * ev.urgency
        + 0.15 * ev.confidence
        + 0.15 * ev.actionability
        - 0.20 * ev.user_attention_cost
    )


def decide_surface(ev: AttentionEvent) -> Surface:
    """Pure function: event → surface decision."""
    if ev.suggested_surface is not None:
        # Honor explicit suggestion unless it violates safety rules
        if ev.suggested_surface == Surface.INTERRUPT and not ev.interruption_allowed:
            return Surface.SURFACE
        return ev.suggested_surface

    s = _score(ev)

    # Hard interrupt paths
    if ev.why_now == WhyNow.SAFETY and ev.urgency >= 0.75:
        return Surface.INTERRUPT if ev.interruption_allowed else Surface.SURFACE
    if ev.why_now == WhyNow.AGENT_BLOCKED and ev.urgency >= 0.6:
        return Surface.SPEAK if s >= _SPEAK_SCORE else Surface.SURFACE

    if s >= _INTERRUPT_FLOOR and ev.interruption_allowed and ev.urgency >= 0.85:
        return Surface.INTERRUPT
    if s >= _SPEAK_SCORE:
        return Surface.SPEAK
    if s >= _SURFACE_SCORE:
        return Surface.SURFACE
    if s >= _PASSIVE_SCORE:
        return Surface.PASSIVE
    return Surface.SILENT


# ── Kind presets (common events) ──────────────────────────────────────────
PRESETS: dict[str, dict[str, Any]] = {
    "download_complete": dict(
        relevance=0.35, urgency=0.25, actionability=0.4,
        user_attention_cost=0.2, why_now=WhyNow.ROUTINE,
        suggested_surface=Surface.PASSIVE,
    ),
    "email_ordinary": dict(
        relevance=0.25, urgency=0.2, actionability=0.3,
        user_attention_cost=0.3, why_now=WhyNow.ROUTINE,
        suggested_surface=Surface.SILENT,
    ),
    "meeting_soon": dict(
        relevance=0.85, urgency=0.8, actionability=0.7,
        user_attention_cost=0.4, why_now=WhyNow.DEADLINE,
        suggested_surface=Surface.SURFACE,
    ),
    "build_failed": dict(
        relevance=0.9, urgency=0.75, actionability=0.85,
        user_attention_cost=0.35, why_now=WhyNow.ANOMALY,
        suggested_surface=Surface.SPEAK,
    ),
    "agent_blocked": dict(
        relevance=0.8, urgency=0.7, actionability=0.9,
        user_attention_cost=0.45, why_now=WhyNow.AGENT_BLOCKED,
        suggested_surface=Surface.SURFACE,
    ),
    "dangerous_action": dict(
        relevance=1.0, urgency=0.95, actionability=1.0,
        user_attention_cost=0.2, why_now=WhyNow.SAFETY,
        interruption_allowed=True,
        suggested_surface=Surface.INTERRUPT,
    ),
    "system_critical": dict(
        relevance=1.0, urgency=0.95, actionability=0.8,
        user_attention_cost=0.15, why_now=WhyNow.SAFETY,
        suggested_surface=Surface.INTERRUPT,
    ),
    "idle_checkin": dict(
        relevance=0.3, urgency=0.15, actionability=0.2,
        user_attention_cost=0.6, why_now=WhyNow.ROUTINE,
        suggested_surface=Surface.SILENT,  # never nag on idle
    ),
}


class AttentionBroker:
    """
    Central broker. Producers submit events; consumers register handlers per surface.
    """

    def __init__(self):
        self._lock = Lock()
        self._queue: list[AttentionEvent] = []
        self._history: list[AttentionEvent] = []
        self._handlers: dict[Surface, list[Callable[[AttentionEvent], None]]] = {
            s: [] for s in Surface
        }
        self._last_speak_at = 0.0
        self._min_speak_gap = 25.0  # seconds between proactive speaks

    def on(self, surface: Surface, handler: Callable[[AttentionEvent], None]):
        self._handlers[surface].append(handler)

    def submit(
        self,
        kind: str,
        title: str,
        detail: str = "",
        *,
        preset: str | None = None,
        relevance: float | None = None,
        urgency: float | None = None,
        confidence: float | None = None,
        actionability: float | None = None,
        user_attention_cost: float | None = None,
        interruption_allowed: bool | None = None,
        why_now: WhyNow | str | None = None,
        suggested_surface: Surface | str | None = None,
        payload: dict | None = None,
    ) -> AttentionEvent:
        base: dict[str, Any] = {}
        if preset and preset in PRESETS:
            base = dict(PRESETS[preset])

        def pick(name, default, override):
            if override is not None:
                return override
            return base.get(name, default)

        wn = why_now if why_now is not None else base.get("why_now", WhyNow.UNKNOWN)
        if isinstance(wn, str):
            try:
                wn = WhyNow(wn)
            except ValueError:
                wn = WhyNow.UNKNOWN

        ss = suggested_surface if suggested_surface is not None else base.get("suggested_surface")
        if isinstance(ss, str):
            try:
                ss = Surface(ss)
            except ValueError:
                ss = None

        ev = AttentionEvent(
            id=str(uuid.uuid4())[:8],
            kind=kind,
            title=title,
            detail=detail,
            relevance=float(pick("relevance", 0.5, relevance)),
            urgency=float(pick("urgency", 0.5, urgency)),
            confidence=float(pick("confidence", 0.7, confidence)),
            actionability=float(pick("actionability", 0.5, actionability)),
            user_attention_cost=float(pick("user_attention_cost", 0.5, user_attention_cost)),
            interruption_allowed=bool(pick("interruption_allowed", True, interruption_allowed)),
            why_now=wn,
            suggested_surface=ss,
            payload=payload or {},
        )
        ev.decided_surface = decide_surface(ev)

        # Rate-limit proactive SPEAK
        if ev.decided_surface == Surface.SPEAK:
            now = time.time()
            if now - self._last_speak_at < self._min_speak_gap and ev.why_now != WhyNow.SAFETY:
                ev.decided_surface = Surface.SURFACE
            else:
                self._last_speak_at = now

        with self._lock:
            self._queue.append(ev)
            self._history.append(ev)
            if len(self._history) > 200:
                self._history = self._history[-200:]

        self._dispatch(ev)
        return ev

    def _dispatch(self, ev: AttentionEvent):
        surface = ev.decided_surface or Surface.SILENT
        for h in self._handlers.get(surface, []):
            try:
                h(ev)
            except Exception:
                pass
        ev.handled = True

    def pending(self, surface: Surface | None = None) -> list[AttentionEvent]:
        with self._lock:
            if surface is None:
                return list(self._queue)
            return [e for e in self._queue if e.decided_surface == surface]

    def clear_handled(self):
        with self._lock:
            self._queue = [e for e in self._queue if not e.handled]

    def recent(self, n: int = 10) -> list[dict]:
        with self._lock:
            return [asdict(e) for e in self._history[-n:]]


# Process-wide singleton
broker = AttentionBroker()
