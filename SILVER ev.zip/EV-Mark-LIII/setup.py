"""
E.V. MARK LIII — one-time setup.

Installs Python dependencies for THIS OS only (pip env markers filter
Windows/macOS/Linux extras). Then installs Playwright browsers for web automation.

Always resolves paths from this file's directory so it works no matter which
folder you launch setup.py from.
"""
from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path

OS = platform.system()  # "Windows" | "Darwin" | "Linux"
ROOT = Path(__file__).resolve().parent
REQ = ROOT / "requirements.txt"


def _run(label: str, args: list[str]) -> None:
    print(f"\n▶ {label}")
    subprocess.run(args, check=True, cwd=str(ROOT))


def main() -> None:
    print(f"⚙  E.V. MARK LIII setup — detected OS: {OS or 'unknown'}")
    print(f"   Project folder: {ROOT}")

    if not REQ.is_file():
        print(f"\n❌ Could not find requirements.txt at:\n   {REQ}")
        print("   Make sure you extracted the full EV-Mark-LIII folder.")
        sys.exit(1)

    # Make relative imports / later steps consistent
    os.chdir(ROOT)

    _run(
        "Installing Python dependencies (OS-specific extras auto-filtered)…",
        [sys.executable, "-m", "pip", "install", "-r", str(REQ)],
    )

    _run(
        "Installing Playwright browsers (chromium + firefox)…",
        [sys.executable, "-m", "playwright", "install", "chromium", "firefox"],
    )

    if OS == "Windows":
        try:
            import win32com.client  # noqa: F401
        except ImportError:
            postinstall = Path(sys.executable).parent / "Scripts" / "pywin32_postinstall.py"
            print(
                "\n⚠️  pywin32 did not register correctly — desktop-shortcut "
                "creation will use a slower fallback. To fix it, run:\n"
                f'    "{sys.executable}" -m pip install --force-reinstall pywin32\n'
                f'    "{sys.executable}" "{postinstall}" -install'
            )
    elif OS == "Linux":
        print(
            "\nℹ️  Linux note — optional native tools:\n"
            "    • volume      → pulseaudio-utils (pactl)\n"
            "    • brightness  → brightnessctl\n"
            "    • open URLs   → xdg-utils"
        )
    elif OS == "Darwin":
        print(
            "\nℹ️  macOS note — volume/brightness/reminders use osascript.\n"
            "    Safari automation only: python -m playwright install webkit"
        )

    print("\n✅ Setup complete!")
    print(f"   cd \"{ROOT}\"")
    print("   python main.py")
    print("   Paste your Gemini API key when the setup screen appears.")
    print("   (Wake word is disabled — E.V. stays continuously present.)")


if __name__ == "__main__":
    main()
