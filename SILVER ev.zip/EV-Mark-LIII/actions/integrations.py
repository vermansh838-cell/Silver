"""
actions/integrations.py — Third-party app integrations for E.V..

Uses YOUR OWN API credentials for each service (never Anthropic/Claude
account credentials — those cannot be exported or reused here). Each
service is fully optional: if its credentials aren't configured, the
matching tool call returns clear setup instructions instead of failing
silently.

Config lives in config/integrations.json (created on first use), separate
from config/api_keys.json so a broken integration never risks the Gemini
key. Nothing here talks to Anthropic in any way; each service is called
directly with its own official API.

── Notion ────────────────────────────────────────────────────────────────
Needs a Notion "Internal Integration" token (Notion → Settings → My
integrations → New integration → Internal Integration Secret), then share
the pages/databases you want E.V. to touch with that integration from
each page's "Connections" menu. Simple bearer-token API, no OAuth needed.

── Spotify ───────────────────────────────────────────────────────────────
Needs a Client ID + Secret from https://developer.spotify.com/dashboard
(free, instant). Search works immediately with just those two (client-
credentials grant). Playback control (play/pause/skip/queue) needs a
one-time browser authorization — call action='setup' once; E.V. opens
your browser, you approve, and a refresh token is stored locally from
then on. Playback control also requires an active Spotify Premium session
with a device already open somewhere (Spotify's API limitation, not ours).

── Gmail ─────────────────────────────────────────────────────────────────
Needs a Google Cloud OAuth "Desktop app" client (console.cloud.google.com →
APIs & Services → Credentials → Create OAuth client ID → Desktop app),
downloaded as credentials.json into config/. First use opens a browser for
one-time consent; a local token is cached afterward. Requires:
    pip install google-auth-oauthlib google-api-python-client
"""
import base64
import json
import sys
import time
import webbrowser
from email.mime.text import MIMEText
from pathlib import Path
from urllib.parse import urlencode

import requests


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


CONFIG_DIR   = _base_dir() / "config"
CONFIG_PATH  = CONFIG_DIR / "integrations.json"
GMAIL_CREDS  = CONFIG_DIR / "credentials.json"     # user-downloaded, from Google Cloud
GMAIL_TOKEN  = CONFIG_DIR / "gmail_token.json"      # auto-generated on first auth


def _load_cfg() -> dict:
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_cfg(data: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _set_cfg(**kv) -> None:
    cfg = _load_cfg()
    cfg.update({k: v for k, v in kv.items() if v is not None})
    _save_cfg(cfg)


# ════════════════════════════════════════════════════════════════════════
# NOTION
# ════════════════════════════════════════════════════════════════════════

_NOTION_API = "https://api.notion.com/v1"


def _notion_headers() -> dict | None:
    token = _load_cfg().get("notion_api_key", "").strip()
    if not token:
        return None
    return {
        "Authorization": f"Bearer {token}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
    }


NOTION_SETUP_MSG = (
    "Notion isn't set up yet. Create an internal integration at "
    "notion.so/my-integrations, copy its secret, and add it with: "
    "integrations action=configure service=notion api_key=<secret>. "
    "Then share the pages you want me to use with that integration "
    "(page → ⋯ → Connections)."
)


def _notion_search(query: str) -> str:
    headers = _notion_headers()
    if not headers:
        return NOTION_SETUP_MSG
    try:
        r = requests.post(f"{_NOTION_API}/search",
                           headers=headers, json={"query": query, "page_size": 8},
                           timeout=15)
        r.raise_for_status()
        results = r.json().get("results", [])
        if not results:
            return f"No Notion pages found for '{query}'. Make sure they're shared with the integration."
        lines = []
        for item in results:
            title = "Untitled"
            props = item.get("properties", {})
            for p in props.values():
                if p.get("type") == "title" and p.get("title"):
                    title = "".join(t.get("plain_text", "") for t in p["title"]) or title
                    break
            url = item.get("url", "")
            lines.append(f"- {title} ({url})")
        return f"Notion results for '{query}':\n" + "\n".join(lines)
    except requests.exceptions.HTTPError as e:
        return f"Notion search failed: {e.response.status_code} {e.response.text[:150]}"
    except Exception as e:
        return f"Notion search failed: {e}"


def _notion_create_page(parent_page_id: str, title: str, content: str) -> str:
    headers = _notion_headers()
    if not headers:
        return NOTION_SETUP_MSG
    if not parent_page_id:
        return "Please specify which Notion page to create this under (parent_page_id)."
    body = {
        "parent": {"page_id": parent_page_id},
        "properties": {"title": {"title": [{"text": {"content": title or "Untitled"}}]}},
    }
    if content:
        body["children"] = [{
            "object": "block", "type": "paragraph",
            "paragraph": {"rich_text": [{"type": "text", "text": {"content": content[:2000]}}]},
        }]
    try:
        r = requests.post(f"{_NOTION_API}/pages", headers=headers, json=body, timeout=15)
        r.raise_for_status()
        url = r.json().get("url", "")
        return f"Created Notion page '{title}'. {url}"
    except requests.exceptions.HTTPError as e:
        return f"Notion page creation failed: {e.response.status_code} {e.response.text[:150]}"
    except Exception as e:
        return f"Notion page creation failed: {e}"


def _notion_append_text(page_id: str, text: str) -> str:
    headers = _notion_headers()
    if not headers:
        return NOTION_SETUP_MSG
    if not page_id or not text:
        return "Need both a page_id and text to append."
    body = {"children": [{
        "object": "block", "type": "paragraph",
        "paragraph": {"rich_text": [{"type": "text", "text": {"content": text[:2000]}}]},
    }]}
    try:
        r = requests.patch(f"{_NOTION_API}/blocks/{page_id}/children",
                            headers=headers, json=body, timeout=15)
        r.raise_for_status()
        return "Added to the Notion page."
    except requests.exceptions.HTTPError as e:
        return f"Notion append failed: {e.response.status_code} {e.response.text[:150]}"
    except Exception as e:
        return f"Notion append failed: {e}"


# ════════════════════════════════════════════════════════════════════════
# SPOTIFY
# ════════════════════════════════════════════════════════════════════════

_SPOTIFY_ACCOUNTS = "https://accounts.spotify.com"
_SPOTIFY_API      = "https://api.spotify.com/v1"
_SPOTIFY_REDIRECT_PORT = 8721
_SPOTIFY_SCOPES = (
    "user-modify-playback-state user-read-playback-state "
    "user-read-currently-playing playlist-modify-private"
)

SPOTIFY_SETUP_MSG = (
    "Spotify isn't set up yet. Create an app at developer.spotify.com/dashboard "
    "(free, instant), then add its Client ID and Secret with: "
    "integrations action=configure service=spotify client_id=<id> client_secret=<secret>. "
    "Search will work right away; for playback control, run "
    "integrations action=setup service=spotify once to authorize in your browser."
)


def _spotify_app_token() -> str | None:
    """Client-credentials token — enough for search, not for playback."""
    cfg = _load_cfg()
    cid, secret = cfg.get("spotify_client_id"), cfg.get("spotify_client_secret")
    if not cid or not secret:
        return None
    cached = cfg.get("spotify_app_token")
    if cached and cfg.get("spotify_app_token_expiry", 0) > time.time() + 30:
        return cached
    basic = base64.b64encode(f"{cid}:{secret}".encode()).decode()
    try:
        r = requests.post(
            f"{_SPOTIFY_ACCOUNTS}/api/token",
            headers={"Authorization": f"Basic {basic}",
                     "Content-Type": "application/x-www-form-urlencoded"},
            data={"grant_type": "client_credentials"}, timeout=10,
        )
        r.raise_for_status()
        tok = r.json()
        _set_cfg(spotify_app_token=tok["access_token"],
                 spotify_app_token_expiry=time.time() + tok.get("expires_in", 3600))
        return tok["access_token"]
    except Exception:
        return None


def _spotify_user_token() -> str | None:
    """User-authorized token — needed for playback control. Auto-refreshes."""
    cfg = _load_cfg()
    cid, secret = cfg.get("spotify_client_id"), cfg.get("spotify_client_secret")
    refresh = cfg.get("spotify_refresh_token")
    if not (cid and secret and refresh):
        return None
    cached = cfg.get("spotify_user_token")
    if cached and cfg.get("spotify_user_token_expiry", 0) > time.time() + 30:
        return cached
    basic = base64.b64encode(f"{cid}:{secret}".encode()).decode()
    try:
        r = requests.post(
            f"{_SPOTIFY_ACCOUNTS}/api/token",
            headers={"Authorization": f"Basic {basic}",
                     "Content-Type": "application/x-www-form-urlencoded"},
            data={"grant_type": "refresh_token", "refresh_token": refresh}, timeout=10,
        )
        r.raise_for_status()
        tok = r.json()
        _set_cfg(spotify_user_token=tok["access_token"],
                 spotify_user_token_expiry=time.time() + tok.get("expires_in", 3600))
        return tok["access_token"]
    except Exception:
        return None


def _spotify_setup() -> str:
    """One-time local OAuth flow — opens browser, catches redirect on localhost."""
    cfg = _load_cfg()
    cid, secret = cfg.get("spotify_client_id"), cfg.get("spotify_client_secret")
    if not cid or not secret:
        return SPOTIFY_SETUP_MSG

    import http.server
    import socketserver
    import threading

    redirect_uri = f"http://127.0.0.1:{_SPOTIFY_REDIRECT_PORT}/callback"
    auth_url = f"{_SPOTIFY_ACCOUNTS}/authorize?" + urlencode({
        "client_id": cid, "response_type": "code", "redirect_uri": redirect_uri,
        "scope": _SPOTIFY_SCOPES,
    })

    result: dict = {}

    class _Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(self.path).query)
            result["code"] = qs.get("code", [None])[0]
            result["error"] = qs.get("error", [None])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            msg = "Spotify connected. You can close this tab." if result.get("code") \
                  else "Authorization failed or was cancelled."
            self.wfile.write(f"<html><body style='font-family:sans-serif'>{msg}</body></html>".encode())

        def log_message(self, *a):
            pass  # silence default request logging

    try:
        httpd = socketserver.TCPServer(("127.0.0.1", _SPOTIFY_REDIRECT_PORT), _Handler)
    except OSError as e:
        return f"Could not start local auth server on port {_SPOTIFY_REDIRECT_PORT}: {e}"

    webbrowser.open(auth_url)
    threading.Thread(target=httpd.handle_request, daemon=True).start()

    waited = 0
    while "code" not in result and waited < 120:
        time.sleep(0.5)
        waited += 0.5
    httpd.server_close()

    if not result.get("code"):
        return "Spotify authorization timed out or was denied. Try again with integrations action=setup service=spotify."

    basic = base64.b64encode(f"{cid}:{secret}".encode()).decode()
    try:
        r = requests.post(
            f"{_SPOTIFY_ACCOUNTS}/api/token",
            headers={"Authorization": f"Basic {basic}",
                     "Content-Type": "application/x-www-form-urlencoded"},
            data={"grant_type": "authorization_code", "code": result["code"],
                  "redirect_uri": redirect_uri}, timeout=10,
        )
        r.raise_for_status()
        tok = r.json()
        _set_cfg(spotify_refresh_token=tok["refresh_token"],
                 spotify_user_token=tok["access_token"],
                 spotify_user_token_expiry=time.time() + tok.get("expires_in", 3600))
        return "Spotify playback control is now authorized."
    except Exception as e:
        return f"Spotify token exchange failed: {e}"


def _spotify_search(query: str, kind: str = "track") -> str:
    token = _spotify_app_token()
    if not token:
        return SPOTIFY_SETUP_MSG
    try:
        r = requests.get(f"{_SPOTIFY_API}/search",
                          headers={"Authorization": f"Bearer {token}"},
                          params={"q": query, "type": kind, "limit": 5}, timeout=10)
        r.raise_for_status()
        items = r.json().get(f"{kind}s", {}).get("items", [])
        if not items:
            return f"No Spotify results for '{query}'."
        lines = []
        for it in items:
            if kind == "track":
                artists = ", ".join(a["name"] for a in it.get("artists", []))
                lines.append(f"- {it['name']} — {artists} ({it['external_urls']['spotify']})")
            else:
                lines.append(f"- {it.get('name')} ({it.get('external_urls', {}).get('spotify', '')})")
        return f"Spotify {kind} results for '{query}':\n" + "\n".join(lines)
    except Exception as e:
        return f"Spotify search failed: {e}"


def _spotify_playback(action: str, uri: str = "") -> str:
    token = _spotify_user_token()
    if not token:
        return ("Playback control needs one-time authorization. "
                "Run integrations action=setup service=spotify first.")
    headers = {"Authorization": f"Bearer {token}"}
    try:
        if action == "play":
            body = {"uris": [uri]} if uri else {}
            r = requests.put(f"{_SPOTIFY_API}/me/player/play", headers=headers, json=body, timeout=10)
        elif action == "pause":
            r = requests.put(f"{_SPOTIFY_API}/me/player/pause", headers=headers, timeout=10)
        elif action == "next":
            r = requests.post(f"{_SPOTIFY_API}/me/player/next", headers=headers, timeout=10)
        elif action == "previous":
            r = requests.post(f"{_SPOTIFY_API}/me/player/previous", headers=headers, timeout=10)
        elif action == "current":
            r = requests.get(f"{_SPOTIFY_API}/me/player/currently-playing", headers=headers, timeout=10)
            if r.status_code == 204 or not r.content:
                return "Nothing is currently playing."
            r.raise_for_status()
            data = r.json()
            item = data.get("item") or {}
            artists = ", ".join(a["name"] for a in item.get("artists", []))
            return f"Now playing: {item.get('name', 'unknown')} — {artists}"
        else:
            return f"Unknown playback action: {action}"

        if r.status_code == 404:
            return "No active Spotify device found — open Spotify on a device first."
        if r.status_code >= 400:
            return f"Spotify playback error: {r.status_code} {r.text[:150]}"
        return f"Playback: {action}."
    except Exception as e:
        return f"Spotify playback failed: {e}"


# ════════════════════════════════════════════════════════════════════════
# GMAIL
# ════════════════════════════════════════════════════════════════════════

_GMAIL_SCOPES = ["https://www.googleapis.com/auth/gmail.send",
                  "https://www.googleapis.com/auth/gmail.readonly"]

GMAIL_SETUP_MSG = (
    "Gmail isn't set up yet. In Google Cloud Console, create an OAuth client "
    "of type 'Desktop app', download it, and save it as config/credentials.json. "
    "Then run: pip install google-auth-oauthlib google-api-python-client, and "
    "call integrations action=setup service=gmail once to authorize in your browser."
)


def _gmail_service():
    try:
        from google.auth.transport.requests import Request as _GRequest
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        from googleapiclient.discovery import build
    except ImportError:
        return None, ("Gmail integration needs extra packages: "
                       "pip install google-auth-oauthlib google-api-python-client")

    creds = None
    if GMAIL_TOKEN.exists():
        creds = Credentials.from_authorized_user_file(str(GMAIL_TOKEN), _GMAIL_SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(_GRequest())
        else:
            if not GMAIL_CREDS.exists():
                return None, GMAIL_SETUP_MSG
            flow = InstalledAppFlow.from_client_secrets_file(str(GMAIL_CREDS), _GMAIL_SCOPES)
            creds = flow.run_local_server(port=0)
        GMAIL_TOKEN.write_text(creds.to_json(), encoding="utf-8")
    return build("gmail", "v1", credentials=creds), None


def _gmail_send(to: str, subject: str, body: str) -> str:
    service, err = _gmail_service()
    if err:
        return err
    if not to or not body:
        return "Need a recipient and a message body to send an email."
    try:
        msg = MIMEText(body)
        msg["to"] = to
        msg["subject"] = subject or "(no subject)"
        raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
        service.users().messages().send(userId="me", body={"raw": raw}).execute()
        return f"Email sent to {to}."
    except Exception as e:
        return f"Gmail send failed: {e}"


def _gmail_list_recent(max_results: int = 5) -> str:
    service, err = _gmail_service()
    if err:
        return err
    try:
        resp = service.users().messages().list(userId="me", maxResults=max_results).execute()
        msgs = resp.get("messages", [])
        if not msgs:
            return "No recent emails found."
        lines = []
        for m in msgs:
            full = service.users().messages().get(
                userId="me", id=m["id"], format="metadata",
                metadataHeaders=["From", "Subject"]).execute()
            headers = {h["name"]: h["value"] for h in full.get("payload", {}).get("headers", [])}
            snippet = full.get("snippet", "")[:80]
            lines.append(f"- From {headers.get('From', '?')}: {headers.get('Subject', '(no subject)')} — {snippet}")
        return "Recent emails:\n" + "\n".join(lines)
    except Exception as e:
        return f"Gmail list failed: {e}"


def _gmail_search(query: str, max_results: int = 5) -> str:
    service, err = _gmail_service()
    if err:
        return err
    try:
        resp = service.users().messages().list(userId="me", q=query, maxResults=max_results).execute()
        msgs = resp.get("messages", [])
        if not msgs:
            return f"No emails matched '{query}'."
        lines = []
        for m in msgs:
            full = service.users().messages().get(
                userId="me", id=m["id"], format="metadata",
                metadataHeaders=["From", "Subject"]).execute()
            headers = {h["name"]: h["value"] for h in full.get("payload", {}).get("headers", [])}
            lines.append(f"- [{m['id']}] From {headers.get('From', '?')}: {headers.get('Subject', '(no subject)')}")
        return f"Emails matching '{query}':\n" + "\n".join(lines)
    except Exception as e:
        return f"Gmail search failed: {e}"


def _gmail_read(message_id: str) -> str:
    service, err = _gmail_service()
    if err:
        return err
    if not message_id:
        return "Need a message_id — get one from list_recent or search first."
    try:
        full = service.users().messages().get(userId="me", id=message_id, format="full").execute()
        headers = {h["name"]: h["value"] for h in full.get("payload", {}).get("headers", [])}
        snippet = full.get("snippet", "")
        return f"From: {headers.get('From', '?')}\nSubject: {headers.get('Subject', '?')}\n\n{snippet}"
    except Exception as e:
        return f"Gmail read failed: {e}"


# ════════════════════════════════════════════════════════════════════════
# DISPATCH
# ════════════════════════════════════════════════════════════════════════

def integrations_control(parameters: dict = None, player=None) -> str:
    """
    parameters:
        service : notion | spotify | gmail
        action  : depends on service — see below
        configure action (any service): api_key / client_id / client_secret
        Notion  : search(query) | create_page(parent_page_id,title,content)
                  | append_text(page_id,text)
        Spotify : setup | search(query,kind) | play(uri) | pause | next
                  | previous | current
        Gmail   : setup | send(to,subject,body) | list_recent(max_results)
                  | search(query,max_results) | read(message_id)
    """
    params  = parameters or {}
    service = (params.get("service") or "").lower().strip()
    action  = (params.get("action") or "").lower().strip()

    if player:
        player.write_log(f"[integrations] {service}.{action}")

    if action == "configure":
        kv = {}
        for f in ("api_key", "client_id", "client_secret"):
            if params.get(f):
                key = f"{service}_{'api_key' if f == 'api_key' else f}"
                kv[key] = params[f]
        if not kv:
            return "Nothing to configure — pass api_key (Notion) or client_id/client_secret (Spotify)."
        _set_cfg(**kv)
        return f"{service.title()} credentials saved."

    if service == "notion":
        if action == "search":
            return _notion_search(params.get("query", ""))
        if action == "create_page":
            return _notion_create_page(params.get("parent_page_id", ""),
                                        params.get("title", ""), params.get("content", ""))
        if action == "append_text":
            return _notion_append_text(params.get("page_id", ""), params.get("text", ""))
        return "Notion actions: search | create_page | append_text"

    if service == "spotify":
        if action == "setup":
            return _spotify_setup()
        if action == "search":
            return _spotify_search(params.get("query", ""), params.get("kind", "track"))
        if action in ("play", "pause", "next", "previous", "current"):
            return _spotify_playback(action, params.get("uri", ""))
        return "Spotify actions: setup | search | play | pause | next | previous | current"

    if service == "gmail":
        if action == "setup":
            _, err = _gmail_service()
            return err or "Gmail is connected."
        if action == "send":
            return _gmail_send(params.get("to", ""), params.get("subject", ""), params.get("body", ""))
        if action == "list_recent":
            return _gmail_list_recent(int(params.get("max_results", 5)))
        if action == "search":
            return _gmail_search(params.get("query", ""), int(params.get("max_results", 5)))
        if action == "read":
            return _gmail_read(params.get("message_id", ""))
        return "Gmail actions: setup | send | list_recent | search | read"

    return "Specify a service: notion | spotify | gmail."


def integration_status() -> dict:
    """Returns which services are configured — used by the UI status panel."""
    cfg = _load_cfg()
    return {
        "notion":  bool(cfg.get("notion_api_key")),
        "spotify": bool(cfg.get("spotify_client_id") and cfg.get("spotify_client_secret")),
        "spotify_playback": bool(cfg.get("spotify_refresh_token")),
        "gmail":   GMAIL_TOKEN.exists(),
    }
