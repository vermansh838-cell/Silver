"""
actions/automation.py — Productivity / automation helpers for E.V.

Fills gaps vs typical E.V. feature boards:
  • file_organize  — sort a folder by type into subfolders
  • daily_report   — write a daily summary note (Second Brain or Desktop)
  • backup_notes   — copy important notes/memory into a backup folder
  • draft_email    — produce a ready-to-send email draft (optional Gmail send via integrations)
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

# Extension → category
_TYPE_MAP = {
    "Images": {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg", ".heic"},
    "Videos": {".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv"},
    "Audio": {".mp3", ".wav", ".flac", ".aac", ".m4a", ".ogg"},
    "Documents": {".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".md"},
    "Spreadsheets": {".xls", ".xlsx", ".csv", ".ods"},
    "Presentations": {".ppt", ".pptx", ".key"},
    "Archives": {".zip", ".rar", ".7z", ".tar", ".gz"},
    "Code": {".py", ".js", ".ts", ".html", ".css", ".java", ".cpp", ".c", ".json", ".xml"},
}


def _category_for(ext: str) -> str:
    ext = ext.lower()
    for cat, exts in _TYPE_MAP.items():
        if ext in exts:
            return cat
    return "Other"


def file_organize(folder: str, dry_run: bool = False) -> dict:
    """
    Organize files in `folder` into type subfolders (Images, Documents, …).
    Does not touch subdirectories already named as categories.
    """
    root = Path(folder).expanduser()
    if not root.exists() or not root.is_dir():
        return {"error": f"Folder not found: {folder}"}

    moved = []
    skipped = []
    planned = []
    cat_names = set(_TYPE_MAP.keys()) | {"Other"}

    for item in root.iterdir():
        if item.is_dir():
            if item.name in cat_names:
                continue
            skipped.append({"path": str(item), "reason": "directory"})
            continue
        if item.name.startswith("."):
            skipped.append({"path": str(item), "reason": "hidden"})
            continue
        cat = _category_for(item.suffix)
        dest_dir = root / cat
        dest = dest_dir / item.name
        # avoid overwrite
        if dest.exists():
            stem, suf = item.stem, item.suffix
            n = 1
            while dest.exists():
                dest = dest_dir / f"{stem}_{n}{suf}"
                n += 1
        entry = {"from": str(item), "to": str(dest), "category": cat}
        planned.append(entry)
        if not dry_run:
            dest_dir.mkdir(parents=True, exist_ok=True)
            try:
                shutil.move(str(item), str(dest))
                moved.append(entry)
            except Exception as e:
                skipped.append({"path": str(item), "reason": str(e)})

    return {
        "status": "dry_run" if dry_run else "organized",
        "folder": str(root),
        "moved": moved if not dry_run else planned,
        "count": len(moved if not dry_run else planned),
        "skipped": skipped[:20],
    }


def daily_report(include_memory: bool = True, include_system: bool = True) -> dict:
    """
    Build a daily report and save it under the Second Brain (or Desktop fallback).
    """
    lines = [f"# Daily Report — {datetime.now().strftime('%A, %d %B %Y %H:%M')}", ""]

    if include_system:
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=0.3)
            ram = psutil.virtual_memory()
            lines.append("## System")
            lines.append(f"- CPU: {cpu:.0f}%")
            lines.append(f"- RAM: {ram.percent:.0f}% ({ram.used // (1024**3)} / {ram.total // (1024**3)} GB)")
            try:
                disk = psutil.disk_usage("C:\\\\" if os.name == "nt" else "/")
                lines.append(f"- Disk: {disk.percent:.0f}% used")
            except Exception:
                pass
            lines.append("")
        except Exception as e:
            lines.append(f"## System\n- unavailable ({e})\n")

    if include_memory:
        try:
            from memory.memory_manager import load_memory, peek_recent_sessions
            mem = load_memory()
            lines.append("## You (from memory)")
            for cat in ("projects", "wishes", "notes", "episodes"):
                data = mem.get(cat) or {}
                if not data:
                    continue
                lines.append(f"### {cat.title()}")
                for k, v in list(data.items())[-5:]:
                    val = v.get("value", v) if isinstance(v, dict) else v
                    lines.append(f"- {val}")
            sessions = peek_recent_sessions(3)
            if sessions:
                lines.append("### Recent chats")
                for s in sessions:
                    lines.append(f"- [{s.get('date','?')}] {s.get('summary','')}")
            lines.append("")
        except Exception as e:
            lines.append(f"## Memory\n- unavailable ({e})\n")

    # Weather snapshot (best effort)
    try:
        import urllib.request
        url = (
            "https://api.open-meteo.com/v1/forecast?"
            "latitude=19.076&longitude=72.8777&current=temperature_2m,weather_code"
        )
        req = urllib.request.Request(url, headers={"User-Agent": "E.V./1.0"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode())
        temp = (data.get("current") or {}).get("temperature_2m")
        if temp is not None:
            lines.append("## Weather (Mumbai)")
            lines.append(f"- {temp}°C")
            lines.append("")
    except Exception:
        pass

    lines.append("---")
    lines.append("_Generated by E.V. automation · daily_report_")
    body = "\n".join(lines)

    # Prefer Second Brain path
    out_path = None
    try:
        cfg = Path(__file__).resolve().parent.parent / "config" / "obsidian_config.json"
        if cfg.exists():
            vault = Path(json.loads(cfg.read_text(encoding="utf-8")).get("vault_path", ""))
            if vault.exists():
                dest_dir = vault / "E.V. Reports"
                dest_dir.mkdir(parents=True, exist_ok=True)
                out_path = dest_dir / f"Daily_{datetime.now().strftime('%Y-%m-%d')}.md"
    except Exception:
        pass
    if out_path is None:
        desktop = Path.home() / "Desktop"
        desktop.mkdir(parents=True, exist_ok=True)
        out_path = desktop / f"E.V_Daily_{datetime.now().strftime('%Y-%m-%d')}.md"

    out_path.write_text(body, encoding="utf-8")
    return {"status": "ok", "path": str(out_path), "preview": body[:500]}


def backup_notes(dest_folder: Optional[str] = None) -> dict:
    """
    Backup long_term memory + optional Second Brain index into a dated folder.
    """
    base = Path(__file__).resolve().parent.parent
    if dest_folder:
        dest_root = Path(dest_folder).expanduser()
    else:
        dest_root = Path.home() / "Desktop" / "E.V_Backups"
    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    dest = dest_root / f"backup_{stamp}"
    dest.mkdir(parents=True, exist_ok=True)

    copied = []
    for rel in [
        Path("memory") / "long_term.json",
        Path("memory") / "obsidian_index.json",
        Path("config") / "obsidian_config.json",
    ]:
        src = base / rel
        if src.exists():
            target = dest / rel.name
            shutil.copy2(src, target)
            copied.append(str(target))

    # optional: copy a shallow sample of Second Brain notes
    try:
        cfg = base / "config" / "obsidian_config.json"
        if cfg.exists():
            vault = Path(json.loads(cfg.read_text(encoding="utf-8")).get("vault_path", ""))
            if vault.exists():
                notes_dest = dest / "second_brain_sample"
                notes_dest.mkdir(exist_ok=True)
                count = 0
                for md in vault.rglob("*.md"):
                    if count >= 30:
                        break
                    if md.is_file():
                        try:
                            shutil.copy2(md, notes_dest / f"{count:02d}_{md.name}")
                            count += 1
                        except Exception:
                            pass
                copied.append(f"{count} second-brain notes sample → {notes_dest}")
    except Exception as e:
        copied.append(f"second_brain sample skip: {e}")

    return {"status": "ok", "backup_folder": str(dest), "items": copied}


def draft_email(to: str = "", subject: str = "", body: str = "", send: bool = False) -> dict:
    """
    Draft an email. If send=True and Gmail is configured, try integrations send.
    """
    draft = {
        "to": to,
        "subject": subject,
        "body": body,
        "created": datetime.now().isoformat(),
    }
    # save draft locally
    drafts = Path(__file__).resolve().parent.parent / "memory" / "email_drafts"
    drafts.mkdir(parents=True, exist_ok=True)
    path = drafts / f"draft_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    path.write_text(json.dumps(draft, indent=2), encoding="utf-8")

    result = {"status": "draft_saved", "path": str(path), "draft": draft}
    if send and to and subject:
        try:
            from actions.integrations import integrations_control
            r = integrations_control(
                parameters={
                    "service": "gmail",
                    "action": "send",
                    "to": to,
                    "subject": subject,
                    "body": body,
                },
                response=None,
                player=None,
            )
            result["send_result"] = r
            result["status"] = "sent_or_attempted"
        except Exception as e:
            result["send_error"] = str(e)
            result["status"] = "draft_only_send_failed"
    return result


def automation_dispatch(action: str, **kwargs) -> dict:
    action = (action or "").lower().strip()
    if action in ("file_organize", "organize", "organize_files"):
        return file_organize(kwargs.get("folder") or kwargs.get("path") or "", dry_run=bool(kwargs.get("dry_run")))
    if action in ("daily_report", "report"):
        return daily_report()
    if action in ("backup", "backup_notes"):
        return backup_notes(kwargs.get("folder") or kwargs.get("path"))
    if action in ("draft_email", "email", "write_email"):
        return draft_email(
            to=kwargs.get("to") or "",
            subject=kwargs.get("subject") or "",
            body=kwargs.get("body") or kwargs.get("content") or "",
            send=bool(kwargs.get("send")),
        )
    return {
        "error": f"Unknown action: {action}",
        "available": ["file_organize", "daily_report", "backup_notes", "draft_email"],
    }


def run(parameters: dict, player=None, session_memory=None) -> str:
    action = (parameters or {}).get("action") or "file_organize"
    kwargs = {k: v for k, v in (parameters or {}).items() if k != "action"}
    try:
        return str(automation_dispatch(action, **kwargs))
    except TypeError:
        return str(automation_dispatch(action))
    except Exception as e:
        return f"Automation error: {e}"


# ── Auto-discovered TOOL (E.V. Mark LIII action_loader) ─────────────────────
TOOL = {
    "name": "automation",
    "description": """Low-stakes automation: file_organize, daily_report, backup_notes, draft_email. Use for 'handle the boring part', organize folder, backup notes, draft email.""",
    "parameters": {'type': 'OBJECT', 'properties': {'action': {'type': 'STRING', 'description': 'file_organize | daily_report | backup_notes | draft_email'}, 'folder': {'type': 'STRING', 'description': 'Folder for organize/backup'}, 'dry_run': {'type': 'BOOLEAN', 'description': 'Preview only for file_organize'}, 'to': {'type': 'STRING', 'description': 'Email recipient'}, 'subject': {'type': 'STRING', 'description': 'Email subject'}, 'body': {'type': 'STRING', 'description': 'Email body'}}, 'required': ['action']},
    "handler": run,
}
