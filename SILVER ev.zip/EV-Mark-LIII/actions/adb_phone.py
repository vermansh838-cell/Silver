"""
E.V. ADB phone control — unlock / lock / wake / list devices via Android Debug Bridge.

Prerequisites on the PC:
  • Android platform-tools (adb) on PATH, or set adb_path in config/api_keys.json
  • USB debugging enabled on the phone (Developer options)
  • Phone authorized for this computer (accept the RSA prompt once)

Optional wireless:
  adb tcpip 5555  (while USB connected), then connect host:port

PIN/password is stored only in config/api_keys.json under "phone_pin" (or per-device
"device_pins"). Never spoken back by E.V.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional


def _base_dir() -> Path:
    return Path(__file__).resolve().parent.parent


CONFIG_PATH = _base_dir() / "config" / "api_keys.json"
SETTINGS_PATH = _base_dir() / "config" / "app_settings.json"


def _load_json(path: Path) -> dict:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _adb_bin() -> str:
    cfg = _load_json(CONFIG_PATH)
    custom = (cfg.get("adb_path") or "").strip()
    if custom and Path(custom).exists():
        return custom
    found = shutil.which("adb")
    if found:
        return found
    # Common Windows install locations
    for candidate in (
        Path(os.environ.get("LOCALAPPDATA", "")) / "Android" / "Sdk" / "platform-tools" / "adb.exe",
        Path(os.environ.get("USERPROFILE", "")) / "AppData" / "Local" / "Android" / "Sdk" / "platform-tools" / "adb.exe",
        Path(r"C:\Android\platform-tools\adb.exe"),
        Path("/usr/bin/adb"),
        Path("/opt/homebrew/bin/adb"),
    ):
        if candidate.exists():
            return str(candidate)
    return "adb"


def _run_adb(args: list[str], timeout: float = 20.0, serial: Optional[str] = None) -> tuple[int, str, str]:
    cmd = [_adb_bin()]
    if serial:
        cmd += ["-s", serial]
    cmd += args
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        return proc.returncode, (proc.stdout or "").strip(), (proc.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", "adb not found — install Android platform-tools and add adb to PATH"
    except subprocess.TimeoutExpired:
        return 124, "", "adb command timed out"
    except Exception as e:
        return 1, "", str(e)


def _list_devices() -> list[dict]:
    code, out, err = _run_adb(["devices", "-l"])
    if code != 0:
        return []
    devices = []
    for line in out.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        serial, state = parts[0], parts[1]
        model = ""
        m = re.search(r"model:(\S+)", line)
        if m:
            model = m.group(1).replace("_", " ")
        devices.append({"serial": serial, "state": state, "model": model})
    return devices


def _pick_serial(target: Optional[str]) -> tuple[Optional[str], str]:
    devices = _list_devices()
    online = [d for d in devices if d["state"] == "device"]
    if not online:
        unauthorized = [d for d in devices if d["state"] == "unauthorized"]
        if unauthorized:
            return None, "Phone is connected but not authorized. Unlock the phone and accept the USB debugging prompt."
        offline = [d for d in devices if d["state"] != "device"]
        if offline:
            return None, f"No online device. Seen: {', '.join(d['serial']+'('+d['state']+')' for d in offline)}"
        return None, "No Android device found. Enable USB debugging and plug in (or use wireless ADB)."

    if target:
        t = target.strip().lower()
        for d in online:
            if t == d["serial"].lower() or t in (d.get("model") or "").lower() or t in d["serial"].lower():
                return d["serial"], ""
        return None, f"No device matching '{target}'. Online: {', '.join(d['serial'] for d in online)}"

    if len(online) == 1:
        return online[0]["serial"], ""
    return None, "Multiple devices online — specify target serial. Online: " + ", ".join(
        f"{d['serial']} ({d.get('model') or 'unknown'})" for d in online
    )


def _get_pin(serial: Optional[str] = None) -> str:
    cfg = _load_json(CONFIG_PATH)
    settings = _load_json(SETTINGS_PATH)
    pins = {}
    pins.update(settings.get("device_pins") or {})
    pins.update(cfg.get("device_pins") or {})
    if serial and pins.get(serial):
        return str(pins[serial])
    # Prefer explicit phone_pin
    pin = cfg.get("phone_pin") or settings.get("phone_pin") or ""
    return str(pin).strip()


def _save_pin(pin: str, serial: Optional[str] = None) -> None:
    cfg = _load_json(CONFIG_PATH)
    pin = str(pin).strip()
    if serial:
        pins = dict(cfg.get("device_pins") or {})
        pins[serial] = pin
        cfg["device_pins"] = pins
    else:
        cfg["phone_pin"] = pin
    _save_json(CONFIG_PATH, cfg)


def _wake(serial: str) -> None:
    # KEYCODE_WAKEUP = 224, KEYCODE_MENU = 82 (also wakes some devices)
    _run_adb(["shell", "input", "keyevent", "224"], serial=serial)
    time.sleep(0.25)
    _run_adb(["shell", "input", "keyevent", "82"], serial=serial)
    time.sleep(0.35)


def _swipe_up(serial: str) -> None:
    # Generic swipe up from bottom third — works on most modern Android lock screens
    _run_adb(["shell", "input", "swipe", "540", "1800", "540", "800", "300"], serial=serial)
    time.sleep(0.4)


def _enter_pin(serial: str, pin: str) -> None:
    # Prefer input text for PIN (digits). Escape spaces for adb.
    safe = pin.replace(" ", "%s")
    _run_adb(["shell", "input", "text", safe], serial=serial)
    time.sleep(0.25)
    # KEYCODE_ENTER = 66
    _run_adb(["shell", "input", "keyevent", "66"], serial=serial)
    time.sleep(0.3)


def _lock(serial: str) -> None:
    # KEYCODE_SLEEP / POWER
    _run_adb(["shell", "input", "keyevent", "26"], serial=serial)


def adb_phone(
    action: str = "status",
    target: str = "",
    pin: str = "",
    host: str = "",
    port: str = "5555",
    player=None,
    **_kwargs,
) -> str:
    """
    Actions:
      status | list | connect | disconnect | unlock | lock | wake | set_pin | tcpip
    """
    action = (action or "status").lower().strip()

    def log(msg: str) -> None:
        if player and hasattr(player, "write_log"):
            try:
                player.write_log(f"ADB: {msg}")
            except Exception:
                pass

    if action in ("list", "devices", "status") and action != "status":
        devices = _list_devices()
        if not devices:
            code, _, err = _run_adb(["version"])
            if code == 127 or "not found" in err.lower():
                return (
                    "adb not found. Install Android platform-tools, add adb to PATH, "
                    "or set adb_path in config/api_keys.json."
                )
            return "No devices attached. Enable USB debugging and connect the phone."
        lines = [f"{d['serial']}  [{d['state']}]  {d.get('model') or ''}".rstrip() for d in devices]
        return "Devices:\n" + "\n".join(lines)

    if action == "status":
        devices = _list_devices()
        code, ver, err = _run_adb(["version"])
        if code != 0 and ("not found" in err.lower() or code == 127):
            return "ADB missing. Install platform-tools and ensure `adb` is on PATH."
        if not devices:
            return "ADB OK — no phone connected."
        online = [d for d in devices if d["state"] == "device"]
        pin_set = bool(_get_pin())
        return (
            f"ADB OK · {len(online)} online / {len(devices)} listed · "
            f"PIN {'saved' if pin_set else 'NOT set (use set_pin)'} · "
            + ", ".join(f"{d['serial']}({d['state']})" for d in devices)
        )

    if action == "set_pin":
        if not pin:
            return "Provide pin= to save the unlock PIN/password (digits or text)."
        serial = None
        if target:
            serial, err = _pick_serial(target)
            if err and not serial:
                # Still save as global pin
                serial = None
        _save_pin(pin, serial)
        log("PIN saved locally (not spoken).")
        return "Unlock PIN saved. Say 'unlock my phone' when the device is connected."

    if action == "connect":
        endpoint = host.strip()
        if not endpoint and target:
            endpoint = target.strip()
        if not endpoint:
            return "Provide host=IP (and optional port=5555) for wireless ADB."
        if ":" not in endpoint:
            endpoint = f"{endpoint}:{port or '5555'}"
        code, out, err = _run_adb(["connect", endpoint], timeout=15)
        msg = out or err
        log(msg)
        if code == 0 and "connected" in (msg or "").lower():
            return f"Connected to {endpoint}."
        return f"Connect result: {msg or f'exit {code}'}"

    if action == "disconnect":
        endpoint = (host or target or "").strip()
        args = ["disconnect"] + ([endpoint] if endpoint else [])
        code, out, err = _run_adb(args)
        return out or err or ("Disconnected." if code == 0 else f"exit {code}")

    if action == "tcpip":
        serial, err = _pick_serial(target or None)
        if err:
            return err
        p = str(port or "5555")
        code, out, err_s = _run_adb(["tcpip", p], serial=serial)
        return out or err_s or (f"Device listening on TCP {p}. Unplug USB and use action=connect host=<phone-ip>." if code == 0 else f"tcpip failed: {err_s}")

    if action == "wake":
        serial, err = _pick_serial(target or None)
        if err:
            return err
        assert serial
        _wake(serial)
        return f"Wake sent to {serial}."

    if action == "lock":
        serial, err = _pick_serial(target or None)
        if err:
            return err
        assert serial
        _lock(serial)
        return f"Lock (power) sent to {serial}."

    if action in ("unlock", "unlock_phone", "open"):
        serial, err = _pick_serial(target or None)
        if err:
            return err
        assert serial
        use_pin = (pin or _get_pin(serial) or "").strip()
        if not use_pin:
            return (
                "No PIN saved. Set it once: "
                "adb_phone action=set_pin pin=YOUR_PIN "
                "(stored only in local config — I will not repeat it)."
            )
        log(f"Unlocking {serial}…")
        _wake(serial)
        time.sleep(0.3)
        _swipe_up(serial)
        time.sleep(0.35)
        _enter_pin(serial, use_pin)
        # Dismiss any residual keyguard
        _run_adb(["shell", "input", "keyevent", "66"], serial=serial)
        return f"Unlock sequence sent to {serial}. If the PIN is wrong or the layout differs, update phone_pin / try again."

    return (
        f"Unknown action '{action}'. Use: status | list | connect | disconnect | "
        "tcpip | wake | lock | unlock | set_pin"
    )


def run(parameters: dict, player=None, session_memory=None, **kwargs) -> str:
    params = dict(parameters or {})
    # Flatten nested parameters if present
    if isinstance(params.get("parameters"), dict):
        nested = params.pop("parameters")
        for k, v in nested.items():
            params.setdefault(k, v)
    return adb_phone(player=player, **{k: v for k, v in params.items() if k in (
        "action", "target", "pin", "host", "port"
    ) or True})


TOOL = {
    "name": "adb_phone",
    "description": (
        "Control the user's Android phone over ADB: unlock, lock, wake, list devices, "
        "wireless connect. "
        "Use when he says unlock my phone, lock my phone, is my phone connected, "
        "or connect phone over Wi‑Fi. "
        "First-time: phone needs USB debugging on; PIN saved via action=set_pin (never speak the PIN back). "
        "Actions: unlock | lock | wake | status | list | set_pin | connect | disconnect | tcpip."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "unlock | lock | wake | status | list | set_pin | connect | disconnect | tcpip",
            },
            "target": {
                "type": "STRING",
                "description": "Device serial or model fragment when multiple devices",
            },
            "pin": {
                "type": "STRING",
                "description": "PIN/password for set_pin or one-shot unlock (prefer saving with set_pin)",
            },
            "host": {
                "type": "STRING",
                "description": "Phone IP for wireless connect",
            },
            "port": {
                "type": "STRING",
                "description": "Wireless ADB port (default 5555)",
            },
        },
        "required": ["action"],
    },
    "handler": run,
}
