"""
actions/obsidian_brain.py — Obsidian Vault Integration for E.V.

This module transforms your Obsidian vault into E.V.'s second brain, automatically
syncing notes, knowledge, and updates into E.V.'s memory system. 

Features:
  • Real-time file monitoring (add/delete/modify)
  • Automatic markdown to memory indexing
  • Bidirectional sync capabilities
  • Cross-reference linking
  • Full-text search integration
  • Backlink awareness

Setup:
  1. Configure your Obsidian vault path in config/obsidian_config.json
  2. Call obsidian_initialize() once to index existing vault
  3. Call obsidian_start_monitoring() to enable real-time sync
"""

import json
import os
import re
import sys
import time
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Tuple
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileModifiedEvent, FileCreatedEvent, FileDeletedEvent

# Import E.V. memory system
sys.path.insert(0, str(Path(__file__).parent.parent))
from memory.memory_manager import load_memory, update_memory, save_memory


def _base_dir() -> Path:
    """Get base directory of E.V. installation."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = _base_dir()
CONFIG_PATH = BASE_DIR / "config" / "obsidian_config.json"
OBSIDIAN_INDEX_PATH = BASE_DIR / "memory" / "obsidian_index.json"
OBSIDIAN_WATCH_LOCK = threading.Lock()


# ─────────────────────────────────────────────────────────────────────────────
# Config Management
# ─────────────────────────────────────────────────────────────────────────────

def _load_obsidian_config() -> dict:
    """Load Obsidian vault configuration."""
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[Obsidian] ⚠️ Config load error: {e}")
    return {"vault_path": "", "enabled": False, "auto_sync": True}


def _save_obsidian_config(config: dict) -> None:
    """Save Obsidian vault configuration."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")


def setup_obsidian_vault(vault_path: str) -> dict:
    """
    Configure E.V. to use an Obsidian vault as its second brain.
    
    Args:
        vault_path: Full path to your Obsidian vault directory
        
    Returns:
        Configuration dictionary with vault details
    """
    vault = Path(vault_path).resolve()
    
    if not vault.exists():
        return {"error": f"Vault path does not exist: {vault}"}
    
    if not vault.is_dir():
        return {"error": f"Path is not a directory: {vault}"}
    
    config = _load_obsidian_config()
    config["vault_path"] = str(vault)
    config["enabled"] = True
    config["initialized"] = datetime.now().isoformat()
    
    _save_obsidian_config(config)
    print(f"[Obsidian] ✅ Vault configured: {vault}")
    
    return config


# ─────────────────────────────────────────────────────────────────────────────
# Markdown Parsing
# ─────────────────────────────────────────────────────────────────────────────

def _extract_metadata(content: str) -> Tuple[dict, str]:
    """
    Extract YAML frontmatter from markdown file.
    Returns (metadata_dict, content_without_frontmatter)
    """
    if not content.startswith("---"):
        return {}, content
    
    lines = content.split("\n", 1)
    if len(lines) < 2:
        return {}, content
    
    rest = lines[1]
    end_match = rest.find("---")
    
    if end_match == -1:
        return {}, content
    
    yaml_block = rest[:end_match].strip()
    body = rest[end_match + 3:].strip()
    
    metadata = {}
    for line in yaml_block.split("\n"):
        if ":" in line:
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip()
    
    return metadata, body


def _extract_headers(content: str) -> List[str]:
    """Extract all headers from markdown content."""
    headers = []
    for line in content.split("\n"):
        if line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            text = line.lstrip("# ").strip()
            headers.append(text)
    return headers


def _extract_tags(content: str) -> List[str]:
    """Extract hashtags and inline tags from markdown."""
    tags = set()
    # Find #tag format
    tag_pattern = r"#(\w+)"
    tags.update(re.findall(tag_pattern, content))
    return list(tags)


def _extract_links(content: str) -> List[str]:
    """Extract [[wikilinks]] from markdown."""
    links = []
    # Find [[link]] format
    link_pattern = r"\[\[([^\]]+)\]\]"
    raw_links = re.findall(link_pattern, content)
    for link in raw_links:
        # Remove |alias if present
        clean_link = link.split("|")[0].strip()
        links.append(clean_link)
    return links


def _get_first_paragraph(content: str) -> str:
    """Extract the first meaningful paragraph as summary."""
    for line in content.split("\n"):
        line = line.strip()
        if line and not line.startswith("#"):
            return line[:200]
    return ""


def _index_markdown_file(file_path: Path) -> dict:
    """
    Parse markdown file and create searchable index entry.
    
    Returns:
        Dictionary with file metadata and extracted content
    """
    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"[Obsidian] ⚠️ Read error {file_path.name}: {e}")
        return {}
    
    metadata, body = _extract_metadata(content)
    
    # Keep a searchable body preview (full enough for personal knowledge retrieval)
    body_clean = re.sub(r"\s+", " ", body).strip()
    return {
        "file": str(file_path.relative_to(Path(_load_obsidian_config()["vault_path"]))),
        "title": metadata.get("title") or file_path.stem,
        "tags": _extract_tags(content),
        "links": _extract_links(content),
        "headers": _extract_headers(content),
        "summary": metadata.get("description") or _get_first_paragraph(body),
        "body_preview": body_clean[:4000],
        "modified": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(),
        "size": file_path.stat().st_size,
        "metadata": metadata,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Index Management
# ─────────────────────────────────────────────────────────────────────────────

def _load_obsidian_index() -> dict:
    """Load the Obsidian vault index."""
    if OBSIDIAN_INDEX_PATH.exists():
        try:
            return json.loads(OBSIDIAN_INDEX_PATH.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[Obsidian] ⚠️ Index load error: {e}")
    return {"files": {}, "tags": {}, "links": {}, "last_sync": None}


def _save_obsidian_index(index: dict) -> None:
    """Save the Obsidian vault index."""
    OBSIDIAN_INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    OBSIDIAN_INDEX_PATH.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")


def _update_indexes(file_index: dict, file_path: Path) -> None:
    """Update tag and link indexes based on file content."""
    index = _load_obsidian_index()
    
    # Add to file index
    file_key = file_index["file"]
    index["files"][file_key] = file_index
    
    # Update tag index
    for tag in file_index.get("tags", []):
        if tag not in index["tags"]:
            index["tags"][tag] = []
        if file_key not in index["tags"][tag]:
            index["tags"][tag].append(file_key)
    
    # Update link index
    for link in file_index.get("links", []):
        if link not in index["links"]:
            index["links"][link] = []
        if file_key not in index["links"][link]:
            index["links"][link].append(file_key)
    
    index["last_sync"] = datetime.now().isoformat()
    _save_obsidian_index(index)


def _remove_from_indexes(file_path: str) -> None:
    """Remove file from all indexes when deleted."""
    index = _load_obsidian_index()
    
    # Remove from files
    if file_path in index["files"]:
        file_data = index["files"][file_path]
        del index["files"][file_path]
        
        # Remove from tag index
        for tag in file_data.get("tags", []):
            if tag in index["tags"]:
                index["tags"][tag] = [f for f in index["tags"][tag] if f != file_path]
                if not index["tags"][tag]:
                    del index["tags"][tag]
        
        # Remove from link index
        for link in file_data.get("links", []):
            if link in index["links"]:
                index["links"][link] = [f for f in index["links"][link] if f != file_path]
                if not index["links"][link]:
                    del index["links"][link]
    
    index["last_sync"] = datetime.now().isoformat()
    _save_obsidian_index(index)


# ─────────────────────────────────────────────────────────────────────────────
# Memory Sync
# ─────────────────────────────────────────────────────────────────────────────

def _sync_to_memory(file_index: dict) -> None:
    """
    Sync indexed file content to E.V. memory.
    Categorizes content based on tags and metadata.
    """
    title = file_index.get("title", "Unknown")
    summary = file_index.get("summary", "")
    tags = file_index.get("tags", [])
    
    # Determine memory category based on tags/content
    category = "notes"  # default
    if "project" in tags:
        category = "projects"
    elif "person" in tags or "relationship" in tags:
        category = "relationships"
    elif "wish" in tags or "goal" in tags:
        category = "wishes"
    elif "preference" in tags:
        category = "preferences"
    
    # Create memory entry
    memory_entry = {
        category: {
            title: {
                "value": summary[:380],  # Respect max value length
                "source": "obsidian",
                "file": file_index["file"],
            }
        }
    }
    
    # Update E.V. memory
    try:
        update_memory(memory_entry)
        print(f"[Obsidian] 💾 Synced to memory: {title} ({category})")
    except Exception as e:
        print(f"[Obsidian] ⚠️ Memory sync error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# File Watcher
# ─────────────────────────────────────────────────────────────────────────────

class ObsidianVaultHandler(FileSystemEventHandler):
    """Handles file system events for Obsidian vault."""
    
    def _is_markdown(self, path: str) -> bool:
        """Check if file is a markdown file."""
        return path.endswith((".md", ".markdown"))
    
    def on_created(self, event: FileCreatedEvent) -> None:
        """Handle new file creation."""
        if event.is_directory or not self._is_markdown(event.src_path):
            return
        
        file_path = Path(event.src_path)
        print(f"[Obsidian] ➕ New note detected: {file_path.name}")
        
        file_index = _index_markdown_file(file_path)
        if file_index:
            _update_indexes(file_index, file_path)
            _sync_to_memory(file_index)
    
    def on_modified(self, event: FileModifiedEvent) -> None:
        """Handle file modification."""
        if event.is_directory or not self._is_markdown(event.src_path):
            return
        
        file_path = Path(event.src_path)
        print(f"[Obsidian] 🔄 Note updated: {file_path.name}")
        
        file_index = _index_markdown_file(file_path)
        if file_index:
            _update_indexes(file_index, file_path)
            _sync_to_memory(file_index)
    
    def on_deleted(self, event: FileDeletedEvent) -> None:
        """Handle file deletion."""
        if event.is_directory or not self._is_markdown(event.src_path):
            return
        
        file_path = Path(event.src_path)
        print(f"[Obsidian] 🗑️  Note deleted: {file_path.name}")
        
        config = _load_obsidian_config()
        vault_path = Path(config.get("vault_path", ""))
        relative_path = str(file_path.relative_to(vault_path)) if vault_path.exists() else event.src_path
        
        _remove_from_indexes(relative_path)


_observer: Optional[Observer] = None
_observer_lock = threading.Lock()


def obsidian_start_monitoring() -> dict:
    """
    Start real-time monitoring of Obsidian vault.
    
    Returns:
        Status dictionary
    """
    global _observer
    
    config = _load_obsidian_config()
    vault_path = config.get("vault_path")
    
    if not vault_path:
        return {"error": "Obsidian vault not configured. Call setup_obsidian_vault() first."}
    
    vault = Path(vault_path)
    if not vault.exists():
        return {"error": f"Vault path no longer exists: {vault_path}"}
    
    with _observer_lock:
        if _observer is not None and _observer.is_alive():
            return {"status": "Monitoring already active", "vault": str(vault)}
        
        try:
            _observer = Observer()
            handler = ObsidianVaultHandler()
            _observer.schedule(handler, str(vault), recursive=True)
            _observer.start()
            
            print(f"[Obsidian] 👁️  Monitoring started: {vault}")
            return {"status": "Monitoring active", "vault": str(vault)}
        except Exception as e:
            return {"error": f"Failed to start monitoring: {e}"}


def obsidian_stop_monitoring() -> dict:
    """Stop monitoring Obsidian vault."""
    global _observer
    
    with _observer_lock:
        if _observer is not None:
            try:
                _observer.stop()
                _observer.join()
                _observer = None
                print("[Obsidian] ⏹️  Monitoring stopped")
                return {"status": "Monitoring stopped"}
            except Exception as e:
                return {"error": f"Failed to stop monitoring: {e}"}
    
    return {"status": "No monitoring active"}


# ─────────────────────────────────────────────────────────────────────────────
# Indexing & Sync
# ─────────────────────────────────────────────────────────────────────────────

def obsidian_initialize(vault_path: Optional[str] = None) -> dict:
    """
    Initialize and index your entire Obsidian vault.
    
    Args:
        vault_path: Path to vault (optional if already configured)
        
    Returns:
        Initialization report
    """
    config = _load_obsidian_config()
    
    if vault_path:
        setup_result = setup_obsidian_vault(vault_path)
        if "error" in setup_result:
            return setup_result
        config = setup_result
    
    vault = Path(config.get("vault_path", ""))
    if not vault.exists():
        return {"error": "Vault path not configured or invalid"}
    
    print(f"[Obsidian] 🔍 Indexing vault: {vault}")
    
    index = _load_obsidian_index()
    index["files"] = {}
    index["tags"] = {}
    index["links"] = {}
    
    md_files = list(vault.rglob("*.md"))
    
    if not md_files:
        return {"status": "No markdown files found", "count": 0, "vault": str(vault)}
    
    synced_count = 0
    
    for file_path in md_files:
        try:
            file_index = _index_markdown_file(file_path)
            if file_index:
                _update_indexes(file_index, file_path)
                _sync_to_memory(file_index)
                synced_count += 1
        except Exception as e:
            print(f"[Obsidian] ⚠️ Error indexing {file_path.name}: {e}")
    
    _save_obsidian_index(index)
    
    result = {
        "status": "Indexing complete",
        "vault": str(vault),
        "files_indexed": len(md_files),
        "files_synced": synced_count,
        "total_tags": len(index["tags"]),
        "total_links": len(index["links"]),
    }
    
    print(f"[Obsidian] ✅ {result}")
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Search & Retrieval
# ─────────────────────────────────────────────────────────────────────────────

def obsidian_search(query: str, search_type: str = "all") -> dict:
    """
    Full-text search across the entire Second Brain vault (all folders / .md files).
    search_type: all | tags | files | links | content
    """
    index = _load_obsidian_index()
    results = {"query": query, "matches": [], "vault": _load_obsidian_config().get("vault_path")}
    q = (query or "").lower().strip()
    if not q:
        return results

    if search_type in ("all", "files", "content"):
        for file_path, file_data in index.get("files", {}).items():
            hay = " ".join([
                file_path.lower(),
                str(file_data.get("title", "")).lower(),
                str(file_data.get("summary", "")).lower(),
                str(file_data.get("body_preview", "")).lower(),
                " ".join(file_data.get("headers", []) or []).lower(),
                " ".join(file_data.get("tags", []) or []).lower(),
            ])
            if q in hay:
                # relevance: prefer title/path hits
                score = 0
                if q in file_path.lower() or q in str(file_data.get("title", "")).lower():
                    score += 3
                if q in str(file_data.get("summary", "")).lower():
                    score += 2
                if q in str(file_data.get("body_preview", "")).lower():
                    score += 1
                results["matches"].append({
                    "type": "content",
                    "score": score,
                    "path": file_path,
                    "title": file_data.get("title"),
                    "summary": file_data.get("summary"),
                    "snippet": (file_data.get("body_preview") or "")[:400],
                    "tags": file_data.get("tags", []),
                    "headers": file_data.get("headers", [])[:8],
                })
        results["matches"].sort(key=lambda m: m.get("score", 0), reverse=True)
        results["matches"] = results["matches"][:25]

    if search_type in ("all", "tags"):
        for tag, files in index.get("tags", {}).items():
            if q in tag.lower():
                for file_path in files[:10]:
                    results["matches"].append({
                        "type": "tag",
                        "tag": tag,
                        "path": file_path,
                        "title": index.get("files", {}).get(file_path, {}).get("title"),
                    })

    if search_type in ("all", "links"):
        for link, backlinks in index.get("links", {}).items():
            if q in link.lower():
                results["matches"].append({
                    "type": "link",
                    "link": link,
                    "backlinks": backlinks[:15],
                    "backlink_count": len(backlinks),
                })

    results["match_count"] = len(results["matches"])
    return results


def obsidian_list_tree(subpath: str = "", max_depth: int = 4) -> dict:
    """List folders and notes under the Second Brain root (recursive)."""
    config = _load_obsidian_config()
    vault = Path(config.get("vault_path", ""))
    if not vault.exists():
        return {"error": f"Vault not found: {vault}"}
    root = vault / subpath if subpath else vault
    if not root.exists():
        return {"error": f"Path not found: {root}"}

    tree = {"root": str(vault), "path": str(root), "folders": [], "notes": []}
    try:
        for dirpath, dirnames, filenames in os.walk(root):
            rel = str(Path(dirpath).relative_to(vault)).replace("\\", "/")
            depth = 0 if rel == "." else rel.count("/") + (0 if rel == "." else 1)
            if depth > max_depth:
                dirnames[:] = []
                continue
            # skip hidden / system
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            if rel != ".":
                tree["folders"].append(rel)
            for fn in filenames:
                if fn.startswith("."):
                    continue
                if fn.lower().endswith((".md", ".txt", ".json", ".csv")):
                    tree["notes"].append(str((Path(dirpath) / fn).relative_to(vault)).replace("\\", "/"))
        tree["folder_count"] = len(tree["folders"])
        tree["note_count"] = len(tree["notes"])
        tree["notes"] = tree["notes"][:200]
        tree["folders"] = tree["folders"][:100]
    except Exception as e:
        tree["error"] = str(e)
    return tree


def obsidian_read_note(relative_path: str) -> dict:
    """Read a note from anywhere inside the Second Brain vault."""
    config = _load_obsidian_config()
    vault = Path(config.get("vault_path", ""))
    if not vault.exists():
        return {"error": f"Vault not found: {vault}"}
    # prevent path escape
    target = (vault / relative_path).resolve()
    try:
        target.relative_to(vault.resolve())
    except Exception:
        return {"error": "Access denied — path outside Second Brain"}
    if not target.exists() or not target.is_file():
        return {"error": f"Note not found: {relative_path}"}
    try:
        text = target.read_text(encoding="utf-8", errors="ignore")
        return {
            "path": relative_path,
            "title": target.stem,
            "content": text[:12000],
            "chars": len(text),
            "truncated": len(text) > 12000,
        }
    except Exception as e:
        return {"error": str(e)}


def second_brain_context_for_prompt(max_notes: int = 12) -> str:
    """Short summary of Second Brain for system prompt injection."""
    config = _load_obsidian_config()
    vault = config.get("vault_path") or ""
    if not config.get("enabled") or not vault:
        return ""
    index = _load_obsidian_index()
    files = index.get("files") or {}
    if not files:
        return (
            f"Second Brain vault configured at: {vault}\n"
            "Index empty — call second_brain tool with action=initialize if needed."
        )
    # newest by modified
    items = sorted(files.values(), key=lambda f: f.get("modified", ""), reverse=True)[:max_notes]
    lines = [
        f"SECOND BRAIN (personal knowledge of the user) — vault: {vault}",
        f"Indexed notes: {len(files)} | tags: {len(index.get('tags') or {})}",
        "Recent / sample notes:",
    ]
    for f in items:
        lines.append(f"- {f.get('title')} [{f.get('file')}] :: {(f.get('summary') or '')[:120]}")
    lines.append(
        "When the user asks anything personal (projects, goals, preferences, people, notes), "
        "search this vault with the second_brain tool before answering from memory alone."
    )
    return "\n".join(lines)


def obsidian_get_stats() -> dict:
    """Get statistics about your indexed Obsidian vault."""
    config = _load_obsidian_config()
    index = _load_obsidian_index()
    
    return {
        "vault_configured": bool(config.get("vault_path")),
        "vault_path": config.get("vault_path"),
        "total_files": len(index.get("files", {})),
        "total_tags": len(index.get("tags", {})),
        "total_links": len(index.get("links", {})),
        "last_sync": index.get("last_sync"),
        "monitoring_active": _observer is not None and _observer.is_alive() if _observer else False,
    }


def _safe_vault_path(relative_path: str) -> tuple[Path | None, str | None]:
    """Resolve a relative path inside the vault; return (path, error)."""
    config = _load_obsidian_config()
    vault = Path(config.get("vault_path", ""))
    if not vault.exists():
        return None, f"Vault not found: {vault}"
    target = (vault / relative_path).resolve()
    try:
        target.relative_to(vault.resolve())
    except Exception:
        return None, "Access denied — path outside Second Brain"
    return target, None


def obsidian_write_note(relative_path: str, content: str, mode: str = "overwrite") -> dict:
    """
    Create or update a note inside the Second Brain vault.
    mode: overwrite | append | create (fail if exists)
    """
    if not relative_path:
        return {"error": "path required"}
    if not relative_path.lower().endswith(".md"):
        relative_path = relative_path.rstrip("/") + ".md"
    target, err = _safe_vault_path(relative_path)
    if err:
        return {"error": err}
    mode = (mode or "overwrite").lower().strip()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        if mode == "create" and target.exists():
            return {"error": f"Note already exists: {relative_path}"}
        if mode == "append" and target.exists():
            existing = target.read_text(encoding="utf-8", errors="ignore")
            content = existing.rstrip() + "\n\n" + content
        target.write_text(content, encoding="utf-8")
        # refresh index for this file
        try:
            file_index = _index_markdown_file(target)
            if file_index:
                _update_indexes(file_index, target)
        except Exception:
            pass
        return {
            "ok": True,
            "path": relative_path,
            "mode": mode,
            "chars": len(content),
        }
    except Exception as e:
        return {"error": str(e)}


def obsidian_delete_note(relative_path: str) -> dict:
    """Delete a note inside the vault (requires explicit path)."""
    target, err = _safe_vault_path(relative_path)
    if err:
        return {"error": err}
    if not target or not target.exists():
        return {"error": f"Note not found: {relative_path}"}
    try:
        target.unlink()
        try:
            _remove_from_indexes(target)
        except Exception:
            pass
        return {"ok": True, "deleted": relative_path}
    except Exception as e:
        return {"error": str(e)}


def obsidian_export_memory() -> dict:
    """Export all Obsidian-synced entries from E.V. memory."""
    memory = load_memory()
    exported = {"categories": {}, "total_entries": 0}
    
    for category in ["notes", "projects", "relationships", "preferences", "wishes", "identity"]:
        cat_data = memory.get(category, {})
        obsidian_entries = [
            (k, v) for k, v in cat_data.items()
            if isinstance(v, dict) and v.get("source") == "obsidian"
        ]
        if obsidian_entries:
            exported["categories"][category] = dict(obsidian_entries)
            exported["total_entries"] += len(obsidian_entries)
    
    return exported


def _ensure_index_from_vault(max_files: int = 400) -> dict:
    """If index is empty but vault is configured, scan markdown into the index."""
    index = _load_obsidian_index()
    if index.get("files"):
        return index
    cfg = _load_obsidian_config()
    vault = (cfg.get("vault_path") or "").strip()
    if not vault:
        return index
    root = Path(vault)
    if not root.is_dir():
        return index
    count = 0
    try:
        for md in root.rglob("*.md"):
            if count >= max_files:
                break
            if any(str(p).startswith(".") for p in md.parts):
                continue
            try:
                meta = _index_markdown_file(md)
                _update_indexes(meta, md)
                count += 1
            except Exception:
                continue
        index = _load_obsidian_index()
        if count:
            print(f"[Obsidian] Graph auto-indexed {count} notes from vault")
    except Exception as e:
        print(f"[Obsidian] Graph scan failed: {e}")
    return index


def second_brain_graph_snapshot(
    highlight: Optional[List[str]] = None,
    max_nodes: int = 120,
) -> dict:
    """
    Build a knowledge-graph snapshot from the Obsidian index for SILVER UI.
    Nodes = notes; edges = wikilinks. Auto-scans vault if index is empty.
    """
    index = _ensure_index_from_vault()
    files = index.get("files") or {}
    if not files:
        cfg = _load_obsidian_config()
        vault = (cfg.get("vault_path") or "").strip()
        if not vault:
            msg = "No vault path in config/obsidian_config.json"
        elif not Path(vault).is_dir():
            msg = f"Vault not found:\n{vault}"
        else:
            msg = "Vault found but no .md notes yet."
        return {"nodes": [], "edges": [], "count": 0, "message": msg}

    # Prefer notes that have links or tags (more graph-interesting)
    scored = []
    for path, meta in files.items():
        if not isinstance(meta, dict):
            continue
        title = meta.get("title") or Path(path).stem
        links = meta.get("links") or []
        tags = meta.get("tags") or []
        score = len(links) * 2 + len(tags) + 1
        scored.append((score, path, title, links, tags))
    scored.sort(key=lambda x: -x[0])
    scored = scored[:max_nodes]

    nodes = []
    name_to_id = {}
    for i, (_, path, title, links, tags) in enumerate(scored):
        nid = f"n{i}"
        name_to_id[title.lower()] = nid
        name_to_id[Path(path).stem.lower()] = nid
        nodes.append({
            "id": nid,
            "label": title[:40],
            "path": path,
            "tags": tags[:6],
            "group": "note",
        })

    hl = {h.lower().strip() for h in (highlight or []) if h}
    for n in nodes:
        key = n["label"].lower()
        path_key = Path(n["path"]).stem.lower()
        if key in hl or path_key in hl or any(h in n["path"].lower() for h in hl):
            n["state"] = "relevant"
        else:
            n["state"] = "normal"

    edges = []
    seen = set()
    for _, path, title, links, _ in scored:
        src = name_to_id.get(title.lower()) or name_to_id.get(Path(path).stem.lower())
        if not src:
            continue
        for link in links:
            clean = (link or "").split("|")[0].strip().lower()
            dst = name_to_id.get(clean)
            if not dst or dst == src:
                continue
            key = tuple(sorted((src, dst)))
            if key in seen:
                continue
            seen.add(key)
            edges.append({"from": src, "to": dst})

    return {
        "nodes": nodes,
        "edges": edges,
        "count": len(nodes),
        "last_sync": index.get("last_sync"),
    }


# ── Auto-discovered tool for action_loader ───────────────────────────────────

def second_brain(
    action: str = "search",
    query: str = "",
    path: str = "",
    vault_path: str = "",
    search_type: str = "all",
    content: str = "",
    mode: str = "overwrite",
) -> str:
    """Route Second Brain / Obsidian vault operations — full read/write access."""
    action = (action or "search").lower().strip()
    try:
        if action in ("initialize", "setup", "connect"):
            vault = vault_path or query or path
            if vault:
                setup_obsidian_vault(vault)
            result = obsidian_initialize(vault or None)
            try:
                obsidian_start_monitoring()
            except Exception:
                pass
            return str(result)
        if action in ("list", "tree", "browse"):
            return str(obsidian_list_tree(path or query or ""))
        if action in ("read", "open", "note"):
            return str(obsidian_read_note(path or query or ""))
        if action in ("stats", "status"):
            return str(obsidian_get_stats())
        if action in ("write", "create", "update", "append", "save"):
            write_mode = mode or ("append" if action == "append" else "overwrite")
            if action == "create":
                write_mode = "create"
            if action == "append":
                write_mode = "append"
            return str(obsidian_write_note(
                path or query or "",
                content or query or "",
                mode=write_mode,
            ))
        if action in ("delete", "remove"):
            return str(obsidian_delete_note(path or query or ""))
        if action in ("graph", "knowledge_graph", "map"):
            hl = [x.strip() for x in (query or "").split(",") if x.strip()]
            return str(second_brain_graph_snapshot(highlight=hl or None))
        # default search
        return str(obsidian_search(query or path or "", search_type=search_type or "all"))
    except Exception as e:
        return f"Second Brain error: {e}"


TOOL = {
    "name": "second_brain",
    "description": (
        "Full access to the user's Obsidian Second Brain vault: search, read, list, "
        "create, update, append, and delete notes. "
        "ALWAYS use this for personal questions about projects, goals, people, notes, "
        "preferences, or anything that may live in the vault — before answering from "
        "general knowledge. "
        "When the user asks to record, update, or organize knowledge, write/update the note. "
        "action=search | list | read | write | create | update | append | delete | stats | initialize. "
        "For write/create/update/append pass path + content. For initialize pass vault_path."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "search | list | read | write | create | update | append | delete | stats | initialize",
            },
            "query": {
                "type": "STRING",
                "description": "Search query or note topic",
            },
            "path": {
                "type": "STRING",
                "description": "Relative note path (e.g. Projects/AI.md)",
            },
            "content": {
                "type": "STRING",
                "description": "Markdown content for write/create/update/append",
            },
            "mode": {
                "type": "STRING",
                "description": "overwrite | append | create (for write actions)",
            },
            "vault_path": {
                "type": "STRING",
                "description": "Absolute vault path when action=initialize",
            },
            "search_type": {
                "type": "STRING",
                "description": "all | title | content (default all)",
            },
        },
        "required": [],
    },
    "handler": second_brain,
}
